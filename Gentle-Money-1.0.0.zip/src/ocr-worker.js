/* Local Tesseract wrapper: terminating this worker also stops its child worker. */
const vendor=new URL('../vendor/ocr/',self.location.href).href;
importScripts(vendor+'tesseract.min.js');
self.onmessage = async ({data}) => {
  let worker;
  try {
    worker=await Tesseract.createWorker(['tha','eng'],1,{
      workerPath:vendor+'worker.min.js',corePath:vendor,langPath:vendor,
      gzip:false,workerBlobURL:false,cacheMethod:'write',
      logger:info=>self.postMessage({type:'progress',status:info.status,progress:info.progress}),errorHandler:()=>{},
    });
    await worker.setParameters({tessedit_pageseg_mode:'6'});
    const result=await worker.recognize(data.blob);
    self.postMessage({type:'result',text:result.data.text});
  } catch {self.postMessage({type:'error'});}
  finally {if(worker)await worker.terminate();}
};
