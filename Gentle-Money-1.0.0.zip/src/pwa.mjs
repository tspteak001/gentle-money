export function installPWA(){
 const status=document.getElementById('offline-status'),update=document.getElementById('update-status'),button=document.getElementById('check-update');
 let registration;
 const waiting=()=>{if(registration?.waiting)update.textContent='มีรุ่นใหม่พร้อมแล้ว บันทึกและสำรองก่อนปิดทุกหน้าต่างแล้วเปิดใหม่';};
 const fail=()=>{status.textContent='ยังเตรียมออฟไลน์ไม่สำเร็จ เปิดออนไลน์แล้วลองตรวจอีกครั้ง ยังจดรายการและสำรองในหน้านี้ได้';};
 async function ready(){
  if(!navigator.serviceWorker||!window.isSecureContext){status.textContent='ต้องเปิดผ่าน HTTPS หรือ localhost เพื่อเตรียมออฟไลน์ ที่อยู่ HTTP บนเครือข่ายไม่รองรับ';return;}
  try{
   registration=await navigator.serviceWorker.register(new URL('../sw.js',import.meta.url),{scope:new URL('../',import.meta.url).pathname,updateViaCache:'none'});
   const watch=worker=>{worker?.addEventListener('statechange',()=>{if(worker.state==='installed'){if(registration.active)update.textContent='มีรุ่นใหม่พร้อมแล้ว บันทึกและสำรองก่อนปิดทุกหน้าต่างแล้วเปิดใหม่';setTimeout(waiting,0);}if(worker.state==='redundant'){if(!registration.active)fail();else update.textContent='รุ่นใหม่ยังเตรียมไม่ครบ ใช้รุ่นเดิมได้ตามปกติ แล้วตรวจอีกครั้งเมื่อออนไลน์';}});};
   watch(registration.installing);registration.addEventListener('updatefound',()=>watch(registration.installing));waiting();
   await navigator.serviceWorker.ready;
   const probe=()=>{
    const worker=navigator.serviceWorker.controller||registration.active;
    if(!worker){fail();return;}
    const channel=new MessageChannel(),timer=setTimeout(fail,10000);
    channel.port1.onmessage=({data})=>{clearTimeout(timer);channel.port1.close();if(data?.type==='OFFLINE_READY')status.textContent=`พร้อมเปิดออฟไลน์ · รุ่น ${data.release.slice(0,8)} · รวมเครื่องมืออ่านรูปแล้ว`;else fail();};
    worker.postMessage({type:'CHECK_OFFLINE'},[channel.port2]);
   };
   probe();navigator.serviceWorker.addEventListener('controllerchange',probe);
  }catch{fail();}
 }
 button.onclick=async()=>{if(!registration){await ready();return;}try{update.textContent='กำลังตรวจรุ่นใหม่…';await registration.update();update.textContent=registration.installing?'กำลังเตรียมรุ่นใหม่ รอให้ครบก่อนปิดหน้าต่าง':'ตรวจแล้ว คุณยังใช้รุ่นเดิมได้ตามปกติ';waiting();}catch{update.textContent='ยังตรวจรุ่นใหม่ไม่ได้ เปิดออนไลน์แล้วลองอีกครั้ง รุ่นที่เตรียมไว้ยังใช้ได้';}};
 window.addEventListener('offline',()=>{update.textContent='ขณะนี้ไม่มีเครือข่าย ข้อมูลที่จดยังเก็บในอุปกรณ์นี้';});
 ready();
}
