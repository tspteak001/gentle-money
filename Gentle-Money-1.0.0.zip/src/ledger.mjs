// Integer satang only. Pure operations are shared by the browser and Node tests.
export const SCHEMA = 1;
const MAX = 99999999999;
function need(condition, message) { if (!condition) throw new Error(message); }
function text(value, label, max = 100) {
  need(typeof value === 'string' && value.trim().length > 0 && value.trim().length <= max, label);
  return value.normalize('NFC').trim();
}
function integer(n) { need(Number.isSafeInteger(n) && Math.abs(n) <= MAX, 'จำนวนเงินไม่ถูกต้อง'); return n; }
export function parseMoney(value) {
  need(typeof value === 'string' && /^\d{1,9}(\.\d{1,2})?$/.test(value.trim()), 'กรอกจำนวนเงิน เช่น 70.50');
  const [baht, satang = ''] = value.trim().split('.');
  return integer(Number(baht) * 100 + Number(satang.padEnd(2, '0')));
}
export function validDate(value) {
  need(typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value), 'วันที่ต้องเป็น YYYY-MM-DD (ค.ศ.)');
  const d = new Date(value + 'T00:00:00Z');
  need(Number.isFinite(d.getTime()) && d.toISOString().slice(0, 10) === value && value >= '1900-01-01' && value <= '2200-12-31', 'วันที่ไม่ถูกต้อง');
  return value;
}
export function bangkokDate(now = new Date()) {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Bangkok', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(now);
  const get = type => parts.find(p => p.type === type).value;
  return `${get('year')}-${get('month')}-${get('day')}`;
}
export function emptyState() {
  return { schema: SCHEMA, revision: 0, accounts: [], categories: [], entries: [], requests: [] };
}
function account(state, id) { const a = state.accounts.find(a => a.id === id); need(a, 'ไม่พบบัญชี'); return a; }
function entryData(state, data) {
  need(['income', 'expense', 'transfer'].includes(data.kind), 'ประเภทรายการไม่ถูกต้อง');
  integer(data.amount); need(data.amount > 0, 'จำนวนเงินต้องมากกว่า 0');
  const date = validDate(data.date);
  const name = text(data.name, 'กรุณาระบุชื่อรายการ');
  need(data.note === undefined || (typeof data.note === 'string' && data.note.length <= 500), 'หมายเหตุยาวเกิน 500 ตัวอักษร');
  const primary = account(state, data.accountId);
  need(date >= primary.openedOn, 'รายการต้องไม่ก่อนวันตั้งยอดเริ่มต้น');
  if (data.kind === 'transfer') {
    const other = account(state, data.toAccountId);
    need(other.id !== primary.id, 'บัญชีต้นทางและปลายทางต้องต่างกัน');
    need(date >= other.openedOn, 'รายการต้องไม่ก่อนวันตั้งยอดเริ่มต้น');
    need(!data.categoryId, 'การย้ายเงินไม่ใช้หมวดรายรับรายจ่าย');
  } else {
    need(!data.toAccountId, 'ระบุบัญชีปลายทางเฉพาะการย้ายเงิน');
    if (data.categoryId) need(state.categories.some(c => c.id === data.categoryId && c.kind === data.kind), 'หมวดไม่ตรงกับประเภทรายการ');
  }
  return { kind: data.kind, amount: data.amount, date, name, accountId: primary.id,
    toAccountId: data.kind === 'transfer' ? data.toAccountId : null, categoryId: data.categoryId || null,
    ...(data.note?.trim() ? { note: data.note.trim() } : {}) };
}
// All changes return a new state; the caller commits it as one database transaction.
export function apply(state, command) {
  need(state?.schema === SCHEMA, 'รุ่นข้อมูลไม่รองรับ');
  need(command && typeof command === 'object', 'คำสั่งไม่ถูกต้อง');
  need(typeof command.type === 'string', 'คำสั่งไม่ถูกต้อง');
  let next = structuredClone(state);
  const data = command.data || {};
  const id = command.id;
  if (command.type.startsWith('goal.')) {
    return applyGoal(state, command);
  } else if (command.type.startsWith('debt.')) {
    return applyDebt(state, command);
  } else if (command.type.startsWith('bill.')) {
    return applyBill(state, command);
  } else if (command.type === 'account.create') {
    text(id, 'ต้องมีรหัสบัญชี');
    need(!next.accounts.some(a => a.id === id), 'รหัสบัญชีซ้ำ');
    need(['asset', 'liability'].includes(data.type), 'ชนิดบัญชีไม่ถูกต้อง');
    next.accounts.push({ id, name: text(data.name, 'ต้องมีชื่อบัญชี'), type: data.type,
      opening: integer(data.opening), openedOn: validDate(data.openedOn), currency: 'THB' });
  } else if (command.type === 'category.create') {
    text(id, 'ต้องมีรหัสหมวด');
    need(!next.categories.some(c => c.id === id), 'รหัสหมวดซ้ำ');
    need(['income', 'expense'].includes(data.kind), 'ชนิดหมวดไม่ถูกต้อง');
    next.categories.push({ id, name: text(data.name, 'ต้องมีชื่อหมวด'), kind: data.kind });
  } else if (command.type === 'entry.create') {
    text(id, 'ต้องมีรหัสรายการ');
    const normalized = entryData(next, data);
    const key = text(command.requestId, 'ต้องมีรหัสป้องกันการบันทึกซ้ำ');
    const payload = JSON.stringify({ id, ...normalized });
    const previous = next.requests.find(r => r.key === key);
    if (previous) { need(previous.payload === payload, 'รหัสบันทึกซ้ำถูกใช้กับข้อมูลอื่น'); return state; }
    need(!next.entries.some(e => e.id === id), 'รหัสรายการซ้ำ');
    next.entries.push({ id, ...normalized, revision: 1, deleted: false });
    next.requests.push({ key, payload });
  } else if (['entry.update', 'entry.delete'].includes(command.type)) {
    const i = next.entries.findIndex(e => e.id === id && !e.deleted);
    need(i >= 0, 'ไม่พบรายการ');
    const previous = next.entries[i];
    need(command.expectedRevision === previous.revision, 'รายการถูกแก้ไขแล้ว กรุณาโหลดใหม่');
    if (command.type === 'entry.update' && (next.billPayments || []).some(p => p.entryId === id)) {
      need(data.kind === 'expense', 'รายการจ่ายบิลต้องเป็นเงินออก หากยกเลิกการจ่ายให้ลบรายการนี้');
    }
    next.entries[i] = command.type === 'entry.delete'
      ? { ...previous, deleted: true, revision: previous.revision + 1 }
      : { id, ...entryData(next, data), deleted: false, revision: previous.revision + 1 };
    adjustLinkedEntries(next,id,command.type);
  } else { throw new Error('ไม่รองรับคำสั่งนี้'); }
  next.revision++;
  // Reject overflow before persisting. Also verifies referential integrity of entries.
  summarize(next);
  validateGoalBalances(next);
  return next;
}
export function summarize(state, { from = '1900-01-01', to = '2200-12-31' } = {}) {
  validDate(from); validDate(to); need(from <= to, 'ช่วงวันที่ไม่ถูกต้อง');
  const balances = Object.fromEntries(state.accounts.map(a => [a.id, a.openedOn <= to ? a.opening : 0]));
  let income = 0, expense = 0;
  const add = (id, amount) => { need(Object.hasOwn(balances, id), 'ไม่พบบัญชีของรายการ'); balances[id] = integer(balances[id] + amount); };
  for (const e of state.entries) {
    if (e.deleted || e.date > to) continue;
    if (e.kind === 'transfer') { add(e.accountId, -e.amount); add(e.toAccountId, e.amount); }
    else {
      add(e.accountId, e.kind === 'income' ? e.amount : -e.amount);
      if (e.date >= from) {
        if (e.kind === 'income') income = integer(income + e.amount);
        else expense = integer(expense + e.amount);
      }
    }
  }
  const total = type => state.accounts.filter(a => a.type === type).reduce((sum, a) => integer(sum + balances[a.id]), 0);
  const cash = total('asset'), liabilities = total('liability');
  return { balances, cash, liabilities, net: integer(cash + liabilities), income, expense, difference: integer(income - expense) };
}
export function frequentEntries(state, kind, limit = 3) {
  const groups = new Map();
  for (const e of state.entries.filter(e => !e.deleted && e.kind === kind && kind !== 'transfer')) {
    const key = e.name.replace(/\s+/g, ' ').toLocaleLowerCase('th-TH');
    const previous = groups.get(key) || { name: e.name, count: 0, latest: e.date };
    previous.count++; previous.latest = previous.latest > e.date ? previous.latest : e.date;
    groups.set(key, previous);
  }
  return [...groups.values()].sort((a, b) => b.count - a.count || b.latest.localeCompare(a.latest) || a.name.localeCompare(b.name, 'th')).slice(0, limit);
}

// Import checks every record, including tombstones and cross references, before
// any IndexedDB write. Do not repair or silently drop unfamiliar backup data.
export function validateState(state) {
  const check = (ok) => need(ok, 'ข้อมูลในไฟล์สำรองไม่ครบหรือไม่ถูกต้อง');
  const revision = n => check(Number.isSafeInteger(n) && n >= 0);
  const id = v => { check(typeof v === 'string' && v.length > 0 && v.length <= 100); return v; };
  const bool = v => check(typeof v === 'boolean');
  check(state && state.schema === SCHEMA); revision(state.revision);
  const required = ['accounts','categories','entries','requests'];
  const optional = ['bills','billPayments','goals','goalMoves','debts','debtPayments'];
  check(Object.keys(state).every(k => ['schema','revision',...required,...optional].includes(k)));
  for (const key of [...required,...optional]) check((!required.includes(key) && state[key] === undefined) || (Array.isArray(state[key]) && state[key].length <= 100000));
  const unique = (items, key) => { const ids = items.map(key); check(new Set(ids).size === ids.length); };
  for (const key of ['accounts','categories','entries',...optional.filter(k => ['bills','goals','goalMoves','debts'].includes(k))]) unique(state[key] || [], x => id(x.id));
  for (const a of state.accounts) { check(['asset','liability'].includes(a.type) && a.currency === 'THB'); text(a.name,'ชื่อบัญชีไม่ถูกต้อง'); integer(a.opening); validDate(a.openedOn); }
  for (const c of state.categories) { check(['income','expense'].includes(c.kind)); text(c.name,'ชื่อหมวดไม่ถูกต้อง'); }
  for (const e of state.entries) { entryData(state,e); revision(e.revision); check(e.revision > 0); bool(e.deleted); }
  unique(state.requests, r => id(r.key));
  for (const r of state.requests) { check(typeof r.payload === 'string' && r.payload.length <= 5000); const p = JSON.parse(r.payload); id(p.id); entryData(state,p); check(state.entries.some(e => e.id === p.id)); }
  for (const b of state.bills || []) { billData(state,b); revision(b.revision); bool(b.archived); }
  unique(state.billPayments || [], p => `${p.billId}|${p.dueDate}`);
  unique(state.billPayments || [], p => p.entryId);
  for (const p of state.billPayments || []) { const b = (state.bills || []).find(b => b.id === p.billId), e = state.entries.find(e => e.id === p.entryId); check(b && e && e.kind === 'expense' && dueIsValid(b,p.dueDate)); }
  for (const g of state.goals || []) { goalData(g); revision(g.revision); bool(g.archived); }
  unique((state.goalMoves || []).filter(m => m.entryId), m => m.entryId);
  for (const m of state.goalMoves || []) {
    check((state.goals || []).some(g => g.id === m.goalId)); check(['reserve','release','spend'].includes(m.kind)); integer(m.amount); check(m.amount > 0); check(typeof m.signature === 'string' && m.signature.length <= 10000);
    if (m.kind === 'spend') { const e = state.entries.find(e => e.id === m.entryId); check(e && e.kind === 'expense' && account(state,e.accountId).type === 'asset'); } else check(m.entryId === null);
  }
  validateGoalBalances(state);
  for (const d of state.debts || []) { debtData(d); check(account(state,d.accountId).type === 'liability'); revision(d.revision); bool(d.archived); }
  unique((state.debts || []).filter(d => !d.archived), d => d.accountId);
  unique(state.debtPayments || [], p => `${p.debtId}|${p.dueDate}`);
  unique(state.debtPayments || [], p => p.principalEntryId);
  unique((state.debtPayments || []).filter(p => p.feeEntryId), p => p.feeEntryId);
  for (const p of state.debtPayments || []) {
    const d = (state.debts || []).find(d => d.id === p.debtId), e = state.entries.find(e => e.id === p.principalEntryId);
    check(d && e && e.kind === 'transfer' && e.toAccountId === d.accountId && account(state,e.accountId).type === 'asset');
    check(dueIsValid({ dueDate:d.firstDue, repeat:d.repeat },p.dueDate)); check(typeof p.signature === 'string' && p.signature.length <= 10000);
    if (p.feeEntryId) { const f = state.entries.find(f => f.id === p.feeEntryId); check(f && f.kind === 'expense' && f.accountId === e.accountId && f.date === e.date && f.deleted === e.deleted); }
  }
  summarize(state); reservedMoney(state);
  return state;
}

// Bills are plans. Only the linked expense changes balances.
export function scheduledDate(first, repeat, index) {
  validDate(first); need(Number.isSafeInteger(index) && index >= 0 && index <= 3600, 'รอบบิลไม่ถูกต้อง');
  need(['once', 'monthly', 'yearly'].includes(repeat), 'รอบบิลไม่ถูกต้อง');
  const [year, month, day] = first.split('-').map(Number);
  const offset = repeat === 'monthly' ? index : repeat === 'yearly' ? index * 12 : 0;
  const total = year * 12 + month - 1 + offset, y = Math.floor(total / 12), m = total % 12 + 1;
  const last = new Date(Date.UTC(y, m, 0)).getUTCDate();
  return validDate(`${y}-${String(m).padStart(2,'0')}-${String(Math.min(day, last)).padStart(2,'0')}`);
}
function billData(state, data) {
  const amount = integer(data.amount); need(amount > 0, 'ยอดบิลต้องมากกว่า 0');
  const prepared = integer(data.prepared ?? 0); need(prepared >= 0 && prepared <= amount, 'เงินที่เตรียมไว้ต้องอยู่ระหว่าง 0 กับยอดบิล');
  need(['once', 'monthly', 'yearly'].includes(data.repeat), 'รอบบิลไม่ถูกต้อง');
  if (data.categoryId) need(state.categories.some(c => c.id === data.categoryId && c.kind === 'expense'), 'หมวดบิลไม่ถูกต้อง');
  return { name: text(data.name, 'กรุณาใส่ชื่อบิล'), amount, prepared, dueDate: validDate(data.dueDate), repeat: data.repeat, categoryId: data.categoryId || null };
}
function dueIsValid(bill, due) {
  validDate(due); if (due < bill.dueDate) return false;
  const [y,m] = due.split('-').map(Number), [fy,fm] = bill.dueDate.split('-').map(Number);
  const index = bill.repeat === 'monthly' ? (y-fy)*12+m-fm : bill.repeat === 'yearly' ? y-fy : 0;
  return index >= 0 && scheduledDate(bill.dueDate, bill.repeat, index) === due;
}
export function paidEntry(state, billId, dueDate) {
  const payment = (state.billPayments || []).find(p => p.billId === billId && p.dueDate === dueDate);
  return payment ? state.entries.find(e => e.id === payment.entryId && !e.deleted && e.kind === 'expense') || null : null;
}
function applyBill(state, command) {
  let next = structuredClone(state); next.bills ||= []; next.billPayments ||= [];
  const data = command.data || {}, id = text(command.id, 'ต้องมีรหัสบิล');
  if (command.type === 'bill.create') {
    need(!next.bills.some(b => b.id === id), 'รหัสบิลซ้ำ');
    next.bills.push({ id, ...billData(next, data), revision: 1, archived: false });
  } else {
    let bill = next.bills.find(b => b.id === id && !b.archived); need(bill, 'ไม่พบบิล');
    if (command.type === 'bill.pay') {
      need(dueIsValid(bill, data.dueDate), 'วันครบกำหนดไม่ตรงกับรอบบิล');
      const paid = paidEntry(next,id,data.dueDate);
      if (paid) {
        need(paid.id === (data.existingEntryId || data.entryId), 'บิลรอบนี้จ่ายแล้ว กรุณาโหลดรายการใหม่');
        if (!data.existingEntryId) need(paid.amount===data.amount && paid.date===data.date && paid.accountId===data.accountId, 'ข้อมูลการจ่ายไม่ตรงกับรายการที่บันทึกแล้ว');
        return state;
      }
    }
    need(command.expectedRevision === bill.revision, 'บิลถูกเปลี่ยนแล้ว กรุณาเปิดบิลใหม่');
    if (command.type === 'bill.update') {
      const updated = billData(next,data);
      if (next.billPayments.some(p=>p.billId===id)) need(updated.dueDate===bill.dueDate && updated.repeat===bill.repeat, 'บิลมีประวัติจ่ายแล้ว หากเปลี่ยนรอบให้หยุดบิลเดิมและสร้างบิลใหม่');
      Object.assign(bill,updated); bill.revision++;
    } else if (command.type === 'bill.archive') {
      bill.archived=true; bill.revision++;
    } else if (command.type === 'bill.pay') {
      const preparedFor=billOccurrences(next,data.dueDate).find(o=>o.billId===id)?.dueDate;
      let expense;
      if (data.existingEntryId) {
        expense=next.entries.find(e=>e.id===data.existingEntryId&&!e.deleted&&e.kind==='expense');
        need(expense,'กรุณาเลือกรายจ่ายที่ยังใช้งานอยู่');
        need(data.expectedEntryRevision===expense.revision,'รายจ่ายถูกแก้ไขแล้ว กรุณาเปิดหน้าจ่ายบิลใหม่');
      } else {
        need(data.entryId && data.requestId,'ต้องมีรหัสรายการจ่ายบิล');
        next=apply(next,{type:'entry.create',id:data.entryId,requestId:data.requestId,data:{name:bill.name,amount:data.amount,date:data.date,kind:'expense',accountId:data.accountId,categoryId:bill.categoryId,note:`จ่ายบิลครบกำหนด ${data.dueDate}`}});
        expense=next.entries.find(e=>e.id===data.entryId&&!e.deleted);need(expense,'ไม่พบรายจ่ายที่บันทึก');
        bill=next.bills.find(b=>b.id===id);
      }
      need(!next.billPayments.some(p=>p.entryId===expense.id && !(p.billId===id&&p.dueDate===data.dueDate)), 'รายจ่ายนี้ผูกกับบิลอื่นแล้ว');
      next.billPayments=next.billPayments.filter(p=>!(p.billId===id&&p.dueDate===data.dueDate));
      next.billPayments.push({billId:id,dueDate:data.dueDate,entryId:expense.id});
      bill.revision++;
      // Prepared money is a manually reported plan for the current earliest bill.
      // Consume it for this occurrence only; never carry it into the next round.
      if(preparedFor===data.dueDate)bill.prepared=0;
    } else { throw Error('ไม่รองรับคำสั่งบิลนี้'); }
  }
  next.revision++; summarize(next); assertReservationGrowth(state,next); return next;
}
export function billOccurrences(state, asOf) {
  validDate(asOf); const result=[];
  for (const bill of state.bills || []) {
    if (bill.archived) continue;
    let preparedAvailable=bill.prepared;
    for(let i=0;i<=3600;i++){
      if(bill.repeat==='once'&&i>0)break;
      let due;try{due=scheduledDate(bill.dueDate,bill.repeat,i);}catch{break;}
      const paid=paidEntry(state,bill.id,due);
      if(paid) continue;
      const prepared=preparedAvailable;preparedAvailable=0;
      result.push({billId:bill.id,name:bill.name,amount:bill.amount,prepared,dueDate:due,repeat:bill.repeat,revision:bill.revision,status:due<asOf?'overdue':due===asOf?'today':'upcoming'});
      if(due>asOf) break;
    }
  }
  return result.sort((a,b)=>a.dueDate.localeCompare(b.dueDate)||a.name.localeCompare(b.name,'th'));
}
export function savingForBill(occurrence, asOf) {
  validDate(asOf); const shortfall=Math.max(0,occurrence.amount-occurrence.prepared);
  if(occurrence.dueDate<=asOf)return {shortfall,rounds:0,perMonth:null};
  const [y,m]=occurrence.dueDate.split('-').map(Number),[ay,am]=asOf.split('-').map(Number);
  let rounds=(y-ay)*12+m-am;
  if(scheduledDate(asOf,'monthly',rounds)<occurrence.dueDate)rounds++;
  rounds=Math.max(1,rounds);
  return {shortfall,rounds,perMonth:Math.ceil(shortfall/rounds)};
}

// Earmarking is a plan over existing cash, not a bank transfer or expense.
export function goalBalance(state,id) {
  return (state.goalMoves||[]).filter(m=>m.goalId===id).reduce((sum,m)=>{
    const entry=m.entryId?state.entries.find(e=>e.id===m.entryId&&!e.deleted):null;
    return integer(sum+(m.kind==='reserve'?m.amount:m.kind==='release'?-m.amount:entry?-entry.amount:0));
  },0);
}
function reservedMoney(state){
  const goals=(state.goals||[]).reduce((sum,g)=>integer(sum+goalBalance(state,g.id)),0);
  const bills=(state.bills||[]).filter(b=>!b.archived).reduce((sum,b)=>integer(sum+(b.prepared||0)),0);
  return {goals,bills,total:integer(goals+bills)};
}
export function fundsSummary(state,asOf='2200-12-31') {
  const cash=summarize(state,{to:asOf}).cash,reserved=reservedMoney(state);
  return {cash,...reserved,unassigned:integer(cash-reserved.total),shortfall:Math.max(0,reserved.total-cash)};
}
function validateGoalBalances(state){for(const g of state.goals||[])need(goalBalance(state,g.id)>=0,'รายจ่ายเกินเงินที่กันไว้ในเป้าหมายนี้ กรุณากันเพิ่มก่อน');}
function assertReservationGrowth(before,after){
  validateGoalBalances(after);const previous=reservedMoney(before).total,current=reservedMoney(after).total;
  if(current>previous)need(current<=summarize(after).cash,'เงินที่กันไว้รวมกันเกินเงินที่มี กรุณาลดเงินกันบิลหรือเป้าหมายอื่นก่อน');
}
function goalData(data){
  const target=integer(data.target);need(target>0,'เป้าหมายต้องมากกว่า 0');
  return {name:text(data.name,'กรุณาใส่ชื่อเป้าหมาย'),target,dueDate:data.dueDate?validDate(data.dueDate):null};
}
function applyGoal(state,command){
  let next=structuredClone(state);next.goals||=[];next.goalMoves||=[];
  const id=text(command.id,'ต้องมีรหัสเป้าหมาย'),data=command.data||{};
  if(command.type==='goal.create'){
    need(!next.goals.some(g=>g.id===id),'รหัสเป้าหมายซ้ำ');next.goals.push({id,...goalData(data),revision:1,archived:false});
  }else{
    let goal=next.goals.find(g=>g.id===id);need(goal,'ไม่พบเป้าหมาย');
    const moving=['goal.reserve','goal.release','goal.spend'].includes(command.type);
    const signature=JSON.stringify({type:command.type,data});
    if(moving){text(command.requestId,'ต้องมีรหัสป้องกันจดซ้ำ');const old=next.goalMoves.find(m=>m.id===command.requestId);if(old){need(old.signature===signature&&old.goalId===id,'รหัสเดิมถูกใช้กับข้อมูลอื่น');return state;}}
    need(command.expectedRevision===goal.revision,'เป้าหมายถูกเปลี่ยนแล้ว กรุณาเปิดใหม่');
    if(command.type==='goal.restore'){goal.archived=false;}
    else{
      need(!goal.archived,'เป้าหมายนี้หยุดใช้แล้ว');
      if(command.type==='goal.update'){const updated=goalData(data);need(updated.target>=goalBalance(next,id),'เป้าหมายต่ำกว่าเงินที่กันไว้ ให้คืนเงินส่วนเกินก่อน');Object.assign(goal,updated);}
      else if(command.type==='goal.archive'){need(goalBalance(next,id)===0,'คืนเงินที่กันไว้ก่อนหยุดใช้เป้าหมาย');goal.archived=true;}
      else if(moving){
        let amount,entryId=null;
        if(command.type==='goal.spend'&&data.existingEntryId){
          const e=next.entries.find(e=>e.id===data.existingEntryId&&!e.deleted&&e.kind==='expense');need(e,'ไม่พบรายจ่ายเดิม');need(e.revision===data.expectedEntryRevision,'รายจ่ายถูกแก้ไขแล้ว กรุณาเลือกใหม่');need(account(next,e.accountId).type==='asset','ใช้ได้เฉพาะรายจ่ายจากเงินสดหรือธนาคาร');amount=e.amount;entryId=e.id;
        }else{amount=integer(data.amount);need(amount>0,'จำนวนเงินต้องมากกว่า 0');}
        if(command.type!=='goal.reserve')need(amount<=goalBalance(next,id),'เงินที่กันไว้ในเป้าหมายนี้ไม่พอ');
        else need(integer(goalBalance(next,id)+amount)<=goal.target,'เงินที่กันไว้จะเกินเป้าหมาย กรุณาเพิ่มเป้าหมายก่อน');
        if(command.type==='goal.spend'){
          if(!entryId){need(account(next,data.accountId).type==='asset','จ่ายเงินเก็บจากเงินสดหรือธนาคาร');next=apply(next,{type:'entry.create',id:data.entryId,requestId:command.requestId,data:{kind:'expense',name:text(data.name,'กรุณาระบุค่าใช้จ่าย'),amount,date:validDate(data.date),accountId:data.accountId,categoryId:data.categoryId||null,note:'ใช้เงินจากเป้าหมาย '+goal.name}});entryId=data.entryId;goal=next.goals.find(g=>g.id===id);}
          need(!next.goalMoves.some(m=>m.entryId===entryId),'รายจ่ายนี้ใช้เงินจากเป้าหมายอื่นแล้ว');
        }
        next.goalMoves.push({id:command.requestId,goalId:id,kind:command.type.split('.')[1],amount,entryId,signature});
      }else throw Error('ไม่รองรับคำสั่งเงินเก็บ');
    }
    goal.revision++;
  }
  next.revision++;summarize(next);assertReservationGrowth(state,next);return next;
}
function debtData(data){
  const expected=integer(data.expectedPayment);need(expected>0,'ยอดที่คาดว่าจะจ่ายต้องมากกว่า 0');
  need(['monthly','once'].includes(data.repeat),'รอบหนี้ไม่ถูกต้อง');
  const installments=data.installments??null;need(installments===null||(Number.isSafeInteger(installments)&&installments>0&&installments<=1200),'จำนวนงวดต้องเป็นจำนวนเต็ม 1–1200 หรือเว้นว่าง');
  return {name:text(data.name,'กรุณาใส่ชื่อหนี้'),expectedPayment:expected,firstDue:validDate(data.firstDue),repeat:data.repeat,installments};
}
export function debtPaymentEntry(state,payment){return state.entries.find(e=>e.id===payment.principalEntryId&&!e.deleted&&e.kind==='transfer')||null;}
export function debtOverview(state,asOf='2200-12-31'){
  const {balances}=summarize(state,{to:asOf});
  return state.accounts.filter(a=>a.type==='liability').map(a=>{
    const plan=(state.debts||[]).find(d=>d.accountId===a.id&&!d.archived);
    const payments=plan?(state.debtPayments||[]).filter(p=>p.debtId===plan.id&&debtPaymentEntry(state,p)):[];
    let dueDate=null;
    if(plan){for(let i=0;i<=3600;i++){if(plan.repeat==='once'&&i>0)break;let due;try{due=scheduledDate(plan.firstDue,plan.repeat,i);}catch{break;}if(!payments.some(p=>p.dueDate===due)){dueDate=due;break;}}}
    return {accountId:a.id,name:a.name,remaining:Math.max(0,-balances[a.id]),credit:Math.max(0,balances[a.id]),plan:plan||null,linkDueDate:dueDate,dueDate:balances[a.id]<0?dueDate:null,paidRounds:payments.length,remainingRounds:plan?.installments?Math.max(0,plan.installments-payments.length):null};
  });
}
function applyDebt(state,command){
  let next=structuredClone(state);next.debts||=[];next.debtPayments||=[];
  const id=text(command.id,'ต้องมีรหัสหนี้'),data=command.data||{};
  if(command.type==='debt.create'){
    need(!next.debts.some(d=>d.id===id),'รหัสหนี้ซ้ำ');let accountId=data.accountId;
    if(data.createAccount){const opening=integer(data.openingDebt);need(opening>=0,'ยอดหนี้ต้องไม่ติดลบ');next=apply(next,{type:'account.create',id:accountId,data:{name:data.name,type:'liability',opening:-opening,openedOn:data.openedOn}});}
    need(account(next,accountId).type==='liability','กรุณาเลือกบัญชีหนี้หรือบัตรเครดิต');need(!next.debts.some(d=>d.accountId===accountId&&!d.archived),'บัญชีนี้มีแผนชำระแล้ว');next.debts.push({id,accountId,...debtData(data),revision:1,archived:false});
  }else{
    let debt=next.debts.find(d=>d.id===id&&!d.archived);need(debt,'ไม่พบแผนหนี้');
    const signature=JSON.stringify(data);
    if(command.type==='debt.pay'){
      const prior=next.debtPayments.find(p=>p.debtId===id&&p.dueDate===data.dueDate&&debtPaymentEntry(next,p));
      if(prior){need(prior.signature===signature,'หนี้รอบนี้บันทึกจ่ายแล้ว กรุณาโหลดใหม่');return state;}
    }
    need(command.expectedRevision===debt.revision,'แผนหนี้ถูกเปลี่ยนแล้ว กรุณาเปิดใหม่');
    if(command.type==='debt.update'){
      const updated=debtData(data);if(next.debtPayments.some(p=>p.debtId===id))need(updated.firstDue===debt.firstDue&&updated.repeat===debt.repeat&&updated.installments===debt.installments,'มีประวัติจ่ายแล้ว เปลี่ยนได้เฉพาะชื่อและยอดคาดการณ์');Object.assign(debt,updated);
    }else if(command.type==='debt.archive'){debt.archived=true;}
    else if(command.type==='debt.pay'){
      need(dueIsValid({dueDate:debt.firstDue,repeat:debt.repeat},data.dueDate),'รอบชำระไม่ถูกต้อง');
      const remaining=Math.max(0,-summarize(next).balances[debt.accountId]);
      let principalEntry,feeEntry=null;
      if(data.existingEntryId){
        principalEntry=next.entries.find(e=>e.id===data.existingEntryId&&!e.deleted);need(principalEntry&&principalEntry.kind==='transfer'&&principalEntry.toAccountId===debt.accountId&&account(next,principalEntry.accountId).type==='asset','เลือกรายการย้ายเงินไปบัญชีหนี้นี้');need(principalEntry.revision===data.expectedEntryRevision,'รายการชำระถูกแก้ไขแล้ว กรุณาเลือกใหม่');
      }else{
        const principal=integer(data.principal),fee=integer(data.fee??0);need(principal>0&&fee>=0,'ยอดลดหนี้ต้องมากกว่า 0 และดอกเบี้ยต้องไม่ติดลบ');need(principal<=remaining,'ยอดลดหนี้มากกว่าหนี้ที่เหลือ กรุณาตรวจยอด');need(account(next,data.accountId).type==='asset','จ่ายหนี้จากบัญชีเงินสดหรือธนาคาร');text(data.entryId,'ต้องมีรหัสการจ่าย');
        next=apply(next,{type:'entry.create',id:data.entryId,requestId:data.entryId,data:{kind:'transfer',name:'ชำระ '+debt.name,amount:principal,date:data.date,accountId:data.accountId,toAccountId:debt.accountId,note:'ลดหนี้รอบ '+data.dueDate}});
        principalEntry=next.entries.find(e=>e.id===data.entryId&&!e.deleted);need(principalEntry,'ไม่พบรายการชำระหนี้');
        if(fee>0){next=apply(next,{type:'entry.create',id:data.entryId+'-fee',requestId:data.entryId+'-fee',data:{kind:'expense',name:'ดอกเบี้ย/ค่าธรรมเนียม '+debt.name,amount:fee,date:data.date,accountId:data.accountId,note:'ค่าใช้จ่ายเพิ่มรอบ '+data.dueDate}});feeEntry=next.entries.find(e=>e.id===data.entryId+'-fee'&&!e.deleted);need(feeEntry,'ไม่พบรายการดอกเบี้ย');}
        debt=next.debts.find(d=>d.id===id);
      }
      need(!next.debtPayments.some(p=>p.principalEntryId===principalEntry.id),'รายการนี้ผูกกับการชำระหนี้แล้ว');
      next.debtPayments=next.debtPayments.filter(p=>!(p.debtId===id&&p.dueDate===data.dueDate));next.debtPayments.push({debtId:id,dueDate:data.dueDate,principalEntryId:principalEntry.id,feeEntryId:feeEntry?.id||null,signature});
    }else throw Error('ไม่รองรับคำสั่งหนี้');
    debt.revision++;
  }
  next.revision++;summarize(next);return next;
}
function adjustLinkedEntries(state,id,type){
  const changed=state.entries.find(e=>e.id===id);
  const payment=(state.debtPayments||[]).find(p=>p.principalEntryId===id||p.feeEntryId===id);
  if(payment){const debt=state.debts.find(d=>d.id===payment.debtId),principal=state.entries.find(e=>e.id===payment.principalEntryId),fee=state.entries.find(e=>e.id===payment.feeEntryId);
    if(type==='entry.delete'){for(const e of [principal,fee])if(e&&!e.deleted){e.deleted=true;e.revision++;}}
    else if(id===payment.principalEntryId){need(changed.kind==='transfer'&&changed.toAccountId===debt.accountId&&account(state,changed.accountId).type==='asset','รายการลดหนี้ต้องย้ายเงินจากเงินสด/ธนาคารไปบัญชีหนี้เดิม');need(summarize(state).balances[debt.accountId]<=0,'ยอดชำระเกินหนี้ที่เหลือ');if(fee&&!fee.deleted){fee.date=changed.date;fee.accountId=changed.accountId;fee.revision++;}}
    else need(changed.kind==='expense'&&changed.accountId===principal.accountId&&changed.date===principal.date,'แก้บัญชีหรือวันที่ได้จากรายการชำระหนี้หลัก');
    debt.revision++;
  }
  const touched=new Set([id]);if(type==='entry.delete'&&payment){touched.add(payment.principalEntryId);touched.add(payment.feeEntryId);}
  for(const move of state.goalMoves||[]){if(move.entryId&&touched.has(move.entryId)){const g=state.goals.find(g=>g.id===move.goalId);if(type==='entry.update')need(changed.kind==='expense'&&account(state,changed.accountId).type==='asset','รายการใช้เงินเก็บต้องเป็นรายจ่ายจากเงินสดหรือธนาคาร');if(type==='entry.delete')g.archived=false;g.revision++;}}
}
