import { overview, periodReport, entriesCSV } from './overview.mjs';
import { parseMoney, summarize, validDate } from './ledger.mjs';
import { readSnapshot, writeMeta, snapshotToken, restoreSnapshot, readRecovery } from './database.mjs';
import { BACKUP_LIMIT, encodeBackup, decodeBackup } from './backup.mjs';
import { installLearningUI } from './learning-ui.mjs';

export function installOverviewUI(ctx) {
  const $=id=>document.getElementById(id), node=(tag,text,cls)=>{const n=document.createElement(tag);n.textContent=text;if(cls)n.className=cls;return n;};
  let plan=null, lastExport=null, pending=null, expectedToken=null, from=null, to=null;
  const learning=installLearningUI(ctx);
  const pair=(parent,label,amount)=>{const row=node('div','','pair');row.append(node('span',label),node('span',ctx.money(amount)+' บาท','value'));parent.append(row);};
  const download=(text,name,type)=>{const url=URL.createObjectURL(new Blob([text],{type})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);};
  const filename=prefix=>`${prefix}-${ctx.today()}-${new Date().toISOString().slice(11,19).replaceAll(':','')}`;
  function lastLabel(){ $('backup-last').textContent=lastExport?'เริ่มส่งออกล่าสุด: '+new Date(lastExport).toLocaleString('th-TH')+' · ตรวจไฟล์ในโฟลเดอร์ดาวน์โหลดด้วย':'ยังไม่เคยส่งออกจากเบราว์เซอร์นี้'; }
  function forecast() {
    const target=$('forecast-result');target.replaceChildren();
    if(!plan){learning.render(null);target.append(node('p','เลือกวันและกดคำนวณก่อน เพื่อดูเงินที่เหลือใช้','small muted'));return;}
    if(plan.until<ctx.today()){learning.render(null);target.append(node('p','แผนเดิมสิ้นสุดแล้ว เลือกวันใหม่ก่อนดูเงินเหลือใช้','warning'));return;}
    const f=overview(ctx.getState(),{asOf:ctx.today(),...plan});
    learning.render({...f,until:plan.until});
    target.append(node('p',(f.available<0?'ยังขาดอีก ':'เหลือใช้ประมาณ ')+ctx.money(Math.abs(f.available))+' บาท','forecast-value'+(f.available<0?' warning':'')));
    target.append(node('p','ถึง '+ctx.dateLabel(plan.until)+' · '+(f.living?'เผื่อค่าใช้จ่ายอื่นแล้วตามที่กรอก':'ยังไม่ได้เผื่อค่ากินอยู่หรือค่าใช้จ่ายอื่น'),'small muted'));
    const calculation=node('details',''),summary=node('summary','ดูว่าคำนวณอย่างไร');calculation.append(summary);
    pair(calculation,'เงินที่มีตอนนี้',f.cash);pair(calculation,'หัก เงินเก็บที่ยังกันไว้',-f.goals);pair(calculation,'หัก เงินกันบิลทั้งหมด',-f.bills);pair(calculation,'หัก บิลช่วงนี้ส่วนที่ยังไม่ได้กัน',-f.billUncovered);pair(calculation,'หัก ยอดชำระหนี้ตามแผนช่วงนี้',-f.debtNeeded);pair(calculation,'หัก ค่าใช้จ่ายอื่นที่ยังจะใช้',-f.living);pair(calculation,'เหลือ / ขาด',f.available);
    calculation.append(node('p','เงินกันบิลหักไว้ครั้งเดียว แม้บิลนั้นจะอยู่นอกช่วงนี้ เงินเก็บยังรวมอยู่ในเงินที่มี จึงต้องกันออกก่อนใช้','small muted'));
    for(const b of f.billsDue){calculation.append(node('p',`${b.name} · ${ctx.dateLabel(b.dueDate)} · ยอด ${ctx.money(b.amount)} / กันแล้ว ${ctx.money(b.prepared)} / ยังต้องเตรียม ${ctx.money(b.uncovered)} บาท`,'small'));}
    for(const d of f.debtsDue){calculation.append(node('p',`${d.name} · ${ctx.dateLabel(d.dueDate)} · ตามแผน ${ctx.money(d.amount)} บาท`,'small'));}
    calculation.append(node('p','หนี้ใช้ยอดต่อรอบที่คุณตั้งไว้ อาจต่างจากยอดเรียกเก็บจริง หากจ่ายแล้วต้องเชื่อมรายการหรือยืนยันรอบชำระ ไม่คำนวณดอกเบี้ยล่วงหน้า','small muted'));
    target.append(calculation);
    if(f.debtsWithoutSchedule.length)target.append(node('p','มีหนี้ที่ยังไม่มีรอบชำระในแผน: '+f.debtsWithoutSchedule.map(d=>d.name).join(', ')+' กรุณาตรวจและเผื่อเงินเพิ่ม','warning small'));
    pair(target,'หนี้คงเหลือทั้งหมด',f.debtTotal);
  }
  function report() {
    if(!from||!to)return;
    const r=periodReport(ctx.getState(),from,to),target=$('report-result');target.replaceChildren();
    pair(target,'เงินเข้า',r.income);pair(target,'เงินออก',r.expense);pair(target,'เข้า − ออก',r.difference);
    target.append(node('p',ctx.dateLabel(from)+' – '+ctx.dateLabel(to)+' · ส่วนต่างนี้ไม่ใช่เงินที่เหลือในบัญชี','small muted'));
    const categories=$('category-report');categories.replaceChildren();
    for(const kind of ['expense','income']){categories.append(node('h2',kind==='expense'?'เงินออก':'เงินเข้า'));const groups=r.groups.filter(g=>g.kind===kind);if(!groups.length)categories.append(node('p','ยังไม่มีรายการ','small muted'));for(const g of groups){pair(categories,g.name+' · '+g.count+' รายการ',g.amount);}}
  }
  function render(){forecast();report();}
  const open=()=>ctx.task(async()=>{
    await ctx.refresh();const snapshot=await readSnapshot(ctx.getDB());plan=snapshot.preferences.until?snapshot.preferences:null;lastExport=snapshot.lastExport||null;
    $('forecast-until').min=ctx.today();$('forecast-until').value=plan?.until||ctx.today();$('forecast-living').value=((plan?.living||0)/100).toFixed(2);
    from=ctx.today().slice(0,7)+'-01';to=ctx.today();$('report-from').value=from;$('report-to').value=to;
    pending=null;$('restore-review').hidden=true;$('backup-file').value='';$('backup-status').textContent='';
    $('export-recovery').hidden=!(await readRecovery(ctx.getDB()));lastLabel();render();ctx.show('overview-page');
  });
  $('open-overview').onclick=open;
  $('restore-start').onclick=async()=>{await open();$('backup-details').open=true;};
  $('overview-back').onclick=()=>ctx.show(ctx.getState().accounts.length?'home':'account-page');
  $('forecast-form').onsubmit=e=>{e.preventDefault();ctx.task(async()=>{
    const next={until:validDate($('forecast-until').value),living:parseMoney($('forecast-living').value)};overview(ctx.getState(),{asOf:ctx.today(),...next});
    await writeMeta(ctx.getDB(),'preferences',next);plan=next;ctx.changed();forecast();ctx.message('จำแผนนี้แล้ว ยอดในบัญชีไม่เปลี่ยน');
  });};
  $('report-form').onsubmit=e=>{e.preventDefault();ctx.task(async()=>{const a=$('report-from').value,b=$('report-to').value;periodReport(ctx.getState(),a,b);from=a;to=b;report();});};
  $('export-csv').onclick=()=>ctx.task(async()=>{await ctx.refresh();download(entriesCSV(ctx.getState(),from,to),filename('Gentle-Money-รายงาน')+'.csv','text/csv;charset=utf-8');ctx.message('เริ่มดาวน์โหลดรายงานแล้ว CSV ใช้กู้คืนข้อมูลไม่ได้');});
  $('export-backup').onclick=()=>ctx.task(async()=>{
    $('backup-status').textContent='กำลังรวมข้อมูลและรูป…';const snapshot=await readSnapshot(ctx.getDB()),text=await encodeBackup(snapshot);
    download(text,filename('Gentle-Money-สำรอง')+'.json','application/json');lastExport=new Date().toISOString();await writeMeta(ctx.getDB(),'last-export',lastExport);lastLabel();$('backup-status').textContent='เริ่มดาวน์โหลดแล้ว กรุณาตรวจว่ามีไฟล์อยู่ในโฟลเดอร์ดาวน์โหลด และเก็บสำเนานอกเบราว์เซอร์นี้';
  });
  $('choose-backup').onclick=()=>$('backup-file').click();
  $('backup-file').onchange=()=>ctx.task(async()=>{
    pending=null;expectedToken=null;$('restore-review').hidden=true;$('backup-status').textContent='กำลังตรวจไฟล์และรูป…';
    try{
      const file=$('backup-file').files[0];if(!file){$('backup-status').textContent='';return;}if(file.size>BACKUP_LIMIT)throw Error('ไฟล์ใหญ่เกิน 300 MB');
      // Capture the replacement baseline before asynchronous validation, including
      // photo-only edits that do not change the ledger revision.
      const current=await readSnapshot(ctx.getDB()),candidate=await decodeBackup(await file.text());
      expectedToken=snapshotToken(current);pending=candidate;
      const s=candidate.state,actual=summarize(s,{to:ctx.today()});
      $('restore-summary').textContent=`ไฟล์วันที่ ${new Date(candidate.createdAt).toLocaleString('th-TH')} · ${s.accounts.length} บัญชี · ${s.entries.filter(e=>!e.deleted).length} รายการ · ${(s.bills||[]).length} บิล · ${(s.goals||[]).length} เป้าหมาย · ${(s.debts||[]).length} แผนหนี้ · ${candidate.attachments.length} รูป · เงินที่มี ${ctx.money(actual.cash)} บาท · ข้อมูลปัจจุบันมี ${current.state.entries.filter(e=>!e.deleted).length} รายการ`;
      $('restore-review').hidden=false;$('backup-status').textContent='ตรวจไฟล์ผ่านแล้ว ยังไม่ได้แทนที่ข้อมูล';
    }catch(e){$('backup-status').textContent='ตรวจไม่ผ่าน ข้อมูลเดิมยังอยู่';throw e;}
    finally{$('backup-file').value='';}
  });
  $('cancel-restore').onclick=()=>{pending=null;expectedToken=null;$('restore-review').hidden=true;$('backup-status').textContent='ยกเลิกแล้ว ข้อมูลเดิมยังอยู่';};
  $('confirm-restore').onclick=()=>ctx.task(async()=>{
    if(!pending)throw Error('กรุณาเลือกไฟล์และตรวจข้อมูลก่อน');
    await restoreSnapshot(ctx.getDB(),pending,expectedToken);plan=pending.preferences.until?pending.preferences:null;pending=null;expectedToken=null;
    $('restore-review').hidden=true;$('export-recovery').hidden=false;lastExport=null;lastLabel();
    $('forecast-until').value=plan?.until||ctx.today();$('forecast-living').value=((plan?.living||0)/100).toFixed(2);
    ctx.changed();await ctx.refresh();$('backup-status').textContent='กู้คืนสำเร็จแล้ว รายการและรูปอยู่ครบ สำเนาข้อมูลก่อนกู้คืนดาวน์โหลดได้จากปุ่มด้านล่าง';ctx.message('กู้คืนข้อมูลแล้ว');
  });
  $('export-recovery').onclick=()=>ctx.task(async()=>{const snapshot=await readRecovery(ctx.getDB());if(!snapshot)throw Error('ยังไม่มีสำเนาก่อนกู้คืน');download(await encodeBackup(snapshot,snapshot.createdAt),filename('Gentle-Money-ก่อนกู้คืน')+'.json','application/json');$('backup-status').textContent='เริ่มดาวน์โหลดข้อมูลก่อนกู้คืนครั้งล่าสุดแล้ว';});
  return {render};
}
