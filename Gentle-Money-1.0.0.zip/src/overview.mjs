import { summarize, fundsSummary, billOccurrences, debtOverview, debtPaymentEntry, scheduledDate, validDate } from './ledger.mjs';

export function overview(state, { asOf, until, living = 0 }) {
  validDate(asOf); validDate(until);
  if (until < asOf || !Number.isSafeInteger(living) || living < 0 || living > 99999999999) throw Error('เลือกช่วงตั้งแต่วันนี้และค่าใช้จ่ายที่ไม่ติดลบ');
  // A future-dated payment is not cash received or a settled obligation today.
  const current = { ...state, entries: state.entries.map(e => e.date > asOf ? { ...e, deleted: true } : e) };
  const funds = fundsSummary(current, asOf);
  const bills = billOccurrences(current, until).filter(b => b.dueDate <= until).map(b => ({ ...b, uncovered: Math.max(0, b.amount - b.prepared) }));
  const debtAccounts = debtOverview(current, asOf), debts = [];
  for (const d of debtAccounts) {
    if (!d.plan || !d.remaining) continue;
    const plan = d.plan;
    for (let i = 0; i <= 3600; i++) {
      if ((plan.repeat === 'once' && i > 0) || (plan.installments !== null && i >= plan.installments)) break;
      let dueDate; try { dueDate = scheduledDate(plan.firstDue, plan.repeat, i); } catch { break; }
      if (dueDate > until) break;
      if ((current.debtPayments || []).some(p => p.debtId === plan.id && p.dueDate === dueDate && debtPaymentEntry(current, p))) continue;
      debts.push({ name: plan.name, dueDate, amount: plan.expectedPayment });
    }
  }
  const billUncovered = bills.reduce((s, b) => s + b.uncovered, 0), debtNeeded = debts.reduce((s, d) => s + d.amount, 0);
  const available = funds.cash - funds.goals - funds.bills - billUncovered - debtNeeded - living;
  if (![billUncovered, debtNeeded, available].every(Number.isSafeInteger)) throw Error('ยอดรวมสูงเกินกว่าจะคำนวณได้');
  return { ...funds, billsDue: bills, debtsDue: debts, billUncovered, debtNeeded, living, available,
    debtTotal: debtAccounts.reduce((s, d) => s + d.remaining, 0),
    debtsWithoutSchedule: debtAccounts.filter(d => d.remaining && (!d.plan || !d.dueDate || d.remainingRounds === 0)) };
}

export function periodReport(state, from, to) {
  const totals = summarize(state, { from, to });
  const groups = new Map();
  for (const e of state.entries) {
    if (e.deleted || e.kind === 'transfer' || e.date < from || e.date > to) continue;
    const key = `${e.kind}:${e.categoryId || ''}`;
    const group = groups.get(key) || { kind: e.kind, name: state.categories.find(c => c.id === e.categoryId)?.name || 'ยังไม่ระบุหมวด', amount: 0, count: 0 };
    group.amount += e.amount; group.count++; groups.set(key, group);
  }
  return { ...totals, groups: [...groups.values()].sort((a, b) => b.amount - a.amount) };
}

export function entriesCSV(state, from, to) {
  validDate(from); validDate(to); if (from > to) throw Error('ช่วงวันที่ไม่ถูกต้อง');
  const cell = v => {
    let s = String(v ?? '');
    // Spreadsheet programs can execute text cells beginning with a formula marker.
    if (/^[\s\u0000-\u001f]*[=+@-]/u.test(s) || /^[\t\r\n]/.test(s)) s = "'" + s;
    return '"' + s.replaceAll('"', '""') + '"';
  };
  const rows = [['วันที่ (ค.ศ.)', 'ประเภท', 'รายการ', 'จำนวน (บาท)', 'บัญชี', 'ไปบัญชี', 'หมวด', 'หมายเหตุ']];
  for (const e of state.entries.filter(e => !e.deleted && e.date >= from && e.date <= to).sort((a, b) => a.date.localeCompare(b.date))) {
    rows.push([e.date, { income: 'เงินเข้า', expense: 'เงินออก', transfer: 'ย้ายเงิน' }[e.kind], e.name, (e.amount / 100).toFixed(2), state.accounts.find(a => a.id === e.accountId)?.name, state.accounts.find(a => a.id === e.toAccountId)?.name, state.categories.find(c => c.id === e.categoryId)?.name, e.note]);
  }
  return '\ufeff' + rows.map(row => row.map(cell).join(',')).join('\r\n');
}
