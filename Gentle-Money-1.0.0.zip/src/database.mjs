import { emptyState, apply, SCHEMA, validateState } from './ledger.mjs';
const DB_VERSION = 2;
function open(name, version) {
  return new Promise((resolve, reject) => {
    let blocked = false;
    const request = version ? indexedDB.open(name, version) : indexedDB.open(name);
    request.onupgradeneeded = event => {
      const db = request.result, tx = request.transaction;
      if (event.oldVersion === 0) db.createObjectStore('ledger').add(emptyState(), 'current');
      if (db.version >= 2) {
        const photos = db.createObjectStore('attachments', { keyPath: 'id' });
        photos.createIndex('entryId', 'entryId'); photos.createIndex('hash', 'hash');
        const ledger = tx.objectStore('ledger'), read = ledger.get('current');
        read.onsuccess = () => ledger.put(read.result, 'before-attachments-v2');
      }
    };
    request.onerror = () => reject(request.error);
    request.onblocked = () => { blocked = true; reject(new Error('กรุณาปิดหน้าโปรแกรมอื่นแล้วลองเปิดใหม่')); };
    request.onsuccess = () => {
      const db = request.result;
      if (blocked) { db.close(); return; }
      db.onversionchange = () => db.close(); resolve(db);
    };
  });
}
export async function openDatabase(name = 'gentle-money') {
  let db = await open(name);
  if (db.version > DB_VERSION) { db.close(); throw new Error('ข้อมูลใหม่กว่าโปรแกรม กรุณาโหลดโปรแกรมรุ่นล่าสุด'); }
  if (db.version === DB_VERSION) return db;
  // Commit a consistent backup in the old store before the additive migration.
  try {
    await new Promise((resolve, reject) => {
      const tx = db.transaction('ledger', 'readwrite'), store = tx.objectStore('ledger');
      tx.oncomplete = resolve; tx.onabort = () => reject(tx.error || new Error('สำเนาก่อนอัปเกรดไม่สำเร็จ'));
      const read = store.get('current'); read.onsuccess = () => store.put(read.result, 'before-attachments-v2');
    });
  } finally { db.close(); }
  return open(name, DB_VERSION);
}
function run(db, command, changes = {}) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(command ? ['ledger', 'attachments'] : ['ledger'], command ? 'readwrite' : 'readonly');
    const store = tx.objectStore('ledger'); let result, failure;
    const fail = error => { failure = error; tx.abort(); };
    tx.oncomplete = () => resolve(result);
    tx.onabort = () => reject(failure || tx.error || new Error('บันทึกไม่สำเร็จ กรุณาตรวจพื้นที่ว่างแล้วลองใหม่'));
    const request = store.get('current');
    request.onsuccess = () => {
      try {
        const state = request.result;
        if (!state || state.schema !== SCHEMA) throw new Error('ข้อมูลหายหรือรุ่นข้อมูลไม่รองรับ');
        if(command?.type.startsWith('bill.') && !state.bills)store.put(state,'before-bills-v1');
        if(command && (command.type.startsWith('goal.')||command.type.startsWith('debt.')) && !state.goals && !state.debts)store.put(state,'before-plans-v1');
        result = command ? apply(state, command) : state;
        if (!command) return;
        const add = changes.add || [], remove = changes.remove || [], photoStore = tx.objectStore('attachments');
        // A debt repayment can delete its principal and fee entries together.
        // Remove every affected entry's images in the same transaction too.
        for(const old of state.entries){if(!old.deleted && result.entries.find(e=>e.id===old.id)?.deleted){const photos=photoStore.index('entryId').getAll(old.id);photos.onsuccess=()=>{for(const photo of photos.result)photoStore.delete(photo.id);};}}
        if (!command.type.startsWith('entry.')) {
          if (add.length || remove.length) throw new Error('แนบรูปได้เฉพาะรายการเงิน');
          if (result !== state) store.put(result, 'current'); return;
        }
        const readPhotos = photoStore.index('entryId').getAll(command.id);
        readPhotos.onsuccess = () => {
          try {
            const current = readPhotos.result, entry = result.entries.find(e => e.id === command.id);
            if (!entry || entry.deleted) {
              if (add.length) throw new Error('ไม่สามารถแนบรูปกับรายการที่ลบแล้ว');
              for (const photo of current) photoStore.delete(photo.id);
            } else {
              for (const id of remove) {
                if (!current.some(p => p.id === id)) throw new Error('รูปถูกเปลี่ยนแล้ว กรุณาเปิดรายการใหม่');
                photoStore.delete(id);
              }
              const kept = current.filter(p => !remove.includes(p.id));
              for (const photo of add) {
                if (!(photo.blob instanceof Blob) || photo.blob.size > 20 * 1024 * 1024 || !/^[a-f0-9]{64}$/.test(photo.hash) || typeof photo.id !== 'string') throw new Error('ข้อมูลรูปไม่ถูกต้อง');
                if (kept.some(p => p.hash === photo.hash)) continue;
                if (kept.length >= 10) throw new Error('แนบได้ไม่เกิน 10 รูปต่อรายการ');
                const record = { id: photo.id, entryId: command.id, hash: photo.hash, blob: photo.blob, name: String(photo.name || 'รูปภาพ').slice(0,255), width: photo.width, height: photo.height };
                photoStore.add(record); kept.push(record);
              }
            }
            if (result !== state) store.put(result, 'current');
          } catch (error) { fail(error); }
        };
      } catch (error) { fail(error); }
    };
  });
}
export const readState = db => run(db);
export const commit = (db, command, changes) => run(db, command, changes);
function readAttachments(db, index, value) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction('attachments'), store = tx.objectStore('attachments');
    const request = store.index(index).getAll(value); let result;
    request.onsuccess = () => { result = request.result; };
    tx.oncomplete = () => resolve(result); tx.onabort = () => reject(tx.error);
  });
}
export const attachmentsFor = (db, entryId) => readAttachments(db, 'entryId', entryId);
export const matchesFor = (db, hash) => readAttachments(db, 'hash', hash);

// All stores are read in one transaction, so a second tab cannot split a backup.
export function readSnapshot(db) {
  return new Promise((resolve,reject) => {
    const tx=db.transaction(['ledger','attachments']), store=tx.objectStore('ledger'), result={};
    for(const [key,field] of [['current','state'],['preferences','preferences'],['last-export','lastExport']]) { const r=store.get(key);r.onsuccess=()=>result[field]=r.result; }
    const r=tx.objectStore('attachments').getAll();r.onsuccess=()=>result.attachments=r.result;
    tx.oncomplete=()=>resolve({...result,preferences:result.preferences||{}});tx.onabort=()=>reject(tx.error);
  });
}
export function writeMeta(db,key,value) {
  if(!['preferences','last-export'].includes(key))throw Error('ไม่รองรับข้อมูลนี้');
  return new Promise((resolve,reject)=>{const tx=db.transaction('ledger','readwrite');tx.objectStore('ledger').put(value,key);tx.oncomplete=resolve;tx.onabort=()=>reject(tx.error);});
}
export function snapshotToken(snapshot) {
  return JSON.stringify([snapshot.state,snapshot.preferences||{},snapshot.attachments.map(p=>[p.id,p.entryId,p.hash,p.name,p.width,p.height,p.blob.size,p.blob.type]).sort((a,b)=>a[0].localeCompare(b[0]))]);
}
export function restoreSnapshot(db, snapshot, expectedToken) {
  validateState(snapshot.state);
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(['ledger','attachments'],'readwrite'), ledger=tx.objectStore('ledger'), photos=tx.objectStore('attachments');
    let failure, remaining=3, current={};
    const ready=()=>{if(--remaining)return;try{
      if(snapshotToken(current)!==expectedToken)throw Error('ข้อมูลเปลี่ยนระหว่างตรวจไฟล์ กรุณาเลือกไฟล์และตรวจอีกครั้ง');
      // Keep one complete recovery copy, including originals, atomically with replacement.
      ledger.put({...current,createdAt:new Date().toISOString()},'before-restore-full');
      const next=structuredClone(snapshot.state);next.revision=Math.max(next.revision,current.state.revision)+1;
      if(!Number.isSafeInteger(next.revision))throw Error('รุ่นข้อมูลสูงเกินกว่าจะกู้คืนได้');
      // Invalidate forms already open in another tab, even if this backup happens
      // to carry the same record revisions as the replaced database.
      for(const key of ['entries','bills','goals','debts'])for(const item of next[key]||[]) {
        const old=(current.state[key]||[]).find(x=>x.id===item.id);
        item.revision=Math.max(item.revision,old?.revision||0)+1;
        if(!Number.isSafeInteger(item.revision))throw Error('รุ่นรายการสูงเกินกว่าจะกู้คืนได้');
      }
      ledger.put(next,'current');ledger.put(snapshot.preferences||{},'preferences');ledger.delete('last-export');
      photos.clear();for(const p of snapshot.attachments)photos.add(p);
    }catch(e){failure=e;tx.abort();}};
    const a=ledger.get('current');a.onsuccess=()=>{current.state=a.result;ready();};
    const b=ledger.get('preferences');b.onsuccess=()=>{current.preferences=b.result||{};ready();};
    const c=photos.getAll();c.onsuccess=()=>{current.attachments=c.result;ready();};
    tx.oncomplete=resolve;tx.onabort=()=>reject(failure||tx.error||Error('กู้คืนไม่สำเร็จ ข้อมูลเดิมยังอยู่'));
  });
}
export function readRecovery(db) {
  return new Promise((resolve,reject)=>{const tx=db.transaction('ledger'),r=tx.objectStore('ledger').get('before-restore-full');let result;r.onsuccess=()=>result=r.result;tx.oncomplete=()=>resolve(result);tx.onabort=()=>reject(tx.error);});
}
