export async function preparePhoto(file) {
  if (!(file instanceof Blob) || !file.size || file.size > 20 * 1024 * 1024) throw new Error('กรุณาเลือกรูปขนาดไม่เกิน 20 MB');
  const buffer = await file.arrayBuffer(), bytes = new Uint8Array(buffer);
  const png = [137,80,78,71,13,10,26,10].every((n,i) => bytes[i] === n);
  const jpeg = bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255;
  const ascii = (a,b) => String.fromCharCode(...bytes.slice(a,b));
  const webp = ascii(0,4) === 'RIFF' && ascii(8,12) === 'WEBP';
  if (!png && !jpeg && !webp) throw new Error('รองรับ JPG, PNG และ WebP กรุณาแปลง HEIC หรือ PDF เป็นรูปก่อน');
  const blob = new Blob([buffer], { type: png ? 'image/png' : jpeg ? 'image/jpeg' : 'image/webp' });
  const url = URL.createObjectURL(blob), image = new Image();
  let width, height;
  try {
    image.src = url; await image.decode(); width = image.naturalWidth; height = image.naturalHeight;
    if (!width || !height || width * height > 25000000) throw new Error('กรุณาใช้รูปไม่เกิน 25 ล้านพิกเซล');
  } catch (error) { throw new Error(error.message?.includes('25 ล้าน') ? error.message : 'เปิดรูปนี้ไม่ได้ ลองเลือกรูปที่ชัดเจนอีกครั้ง'); }
  finally { URL.revokeObjectURL(url); }
  const hash = [...new Uint8Array(await crypto.subtle.digest('SHA-256', buffer))].map(n => n.toString(16).padStart(2,'0')).join('');
  return { id: crypto.randomUUID(), blob, name: file.name || 'รูปภาพ', hash, width, height };
}
