import { methods, calculateExample, guidance } from './learning.mjs';
import { parseMoney } from './ledger.mjs';
export function installLearningUI({money,today}) {
 const $=id=>document.getElementById(id),node=(tag,text)=>{const n=document.createElement(tag);n.textContent=text;return n;};
 let current=null;
 for(const m of methods)$('learning-method').add(new Option(m.name,m.id));
 function choose(){
  current=methods.find(m=>m.id===$('learning-method').value);$('learning-description').textContent=current.description;$('learning-fields').replaceChildren();$('learning-result').replaceChildren();$('learning-error').textContent='';
  for(const [id,label,value,type] of current.fields){const l=node('label',label),input=node('input','');input.id='learn-'+id;l.htmlFor=input.id;input.value=value;input.required=true;input.inputMode=type?'numeric':'decimal';input.maxLength=12;$('learning-fields').append(l,input);}
 }
 $('learning-method').onchange=choose;choose();
 $('learning-form').onsubmit=e=>{e.preventDefault();try{
  $('learning-error').textContent='';const data={};for(const [id,,,type] of current.fields){const text=$('learn-'+id).value.trim();if(type){if(!/^\d{1,4}$/.test(text))throw Error('กรอกเปอร์เซ็นต์หรือจำนวนรอบเป็นจำนวนเต็ม');data[id]=Number(text);}else data[id]=parseMoney(text);}
  const result=calculateExample(current.id,data),target=$('learning-result');target.replaceChildren();
  const row=(label,amount)=>target.append(node('p',label+' '+money(amount)+' บาท'));
  if(current.id==='ratio'){row('เรื่องจำเป็น',result.needs);row('ความสุข',result.wants);row('เก็บ / จ่ายหนี้เพิ่มรวมกัน',result.saving);}
  else if('missing'in result){row('ยังขาด',result.missing);row('เฉลี่ยต่อรอบประมาณ',result.perRound);}
  else if('target'in result)row('เป้าหมายในตัวอย่าง',result.target);
  else if('remaining'in result)row(result.remaining<0?'ในตัวอย่างยังขาด':'ในตัวอย่างยังเหลือ',Math.abs(result.remaining));
  else row('เงินที่ลองกันในตัวอย่าง',result.saving);
  target.append(node('p','ตัวอย่างเท่านั้น · ไม่เปลี่ยนยอดบัญชี บิล หนี้ หรือเงินเก็บของคุณ'));
 }catch(error){$('learning-result').replaceChildren();$('learning-error').textContent=error.message;}};
 return {render(forecast){const g=guidance(forecast,today());$('learning-guidance').textContent=g.text+(g.amount!==undefined?' · '+(g.code==='shortfall'?'ขาดตามแผน ':'ส่วนว่างตามแผน ')+money(g.amount)+' บาท':'');}};
}
