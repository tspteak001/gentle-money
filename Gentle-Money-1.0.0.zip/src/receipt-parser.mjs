import { validDate, parseMoney } from './ledger.mjs';
const thaiDigits = '๐๑๒๓๔๕๖๗๘๙';
export function normalizeText(text) { return String(text).replace(/[๐-๙]/g,c=>String(thaiDigits.indexOf(c))).replace(/\u00a0/g,' ').normalize('NFC').replace(/\u0e4d\u0e32/g,'\u0e33'); }
const months=['มค','กพ','มีค','เมย','พค','มิย','กค','สค','กย','ตค','พย','ธค'];
function dateValue(day,month,year) {
  let y=Number(year);if(y>=2400&&y<=2700)y-=543;
  if(y<1900||y>2200)return null;
  const value=`${y}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
  try{return validDate(value);}catch{return null;}
}
export function parseReceipt(text) {
  const normalized=normalizeText(text), lines=normalized.split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
  const dates=[];
  function addDate(value,source){if(value&&!dates.some(d=>d.value===value))dates.push({value,source});}
  for(const line of lines){
    for(const m of line.matchAll(/\b(\d{4})[-/](\d{1,2})[-/](\d{1,2})\b/g))addDate(dateValue(m[3],m[2],m[1]),line);
    for(const m of line.matchAll(/\b(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})\b/g))addDate(dateValue(m[1],m[2],m[3]),line);
    const m=line.match(/(\d{1,2})\s+([ก-๙.]+)\s+(\d{4})/);
    if(m){const month=months.indexOf(m[2].replace(/\./g,''))+1;addDate(dateValue(m[1],month,m[3]),line);}
  }
  const candidates=[];
  for(let i=0;i<lines.length;i++){
    const line=lines[i];
    // Exclude tender/change/tax/fees and subtotal before considering total labels.
    if(/เงินทอน|เงินสด|รับเงินสด|cash|change|subtotal|sub total|ยอดก่อน|ก่อนภาษี|ภาษี|vat|ค่าธรรมเนียม|fee/i.test(line))continue;
    const strong=/grand\s*total|net\s*total|total\s*(amount|due)|ยอดสุทธิ|รวมสุทธิ|ยอดชำระ|ยอดรวม|จำนวนเงิน|ยอดเงิน|รวมเป็นเงิน|amount/i.test(line);
    const total=strong||/(^|\s)total\b|รวมทั้งสิ้น|รวมเงิน/i.test(line);
    if(!total)continue;
    const source=/\d/.test(line)?line:line+' '+(lines[i+1]||'');
    // Only properly formatted decimals or an integer following a total label.
    const tokens=[...source.matchAll(/(?<![\d./:-])(?:\d{1,3}(?:,\d{3})+|\d{1,9})\.\d{2}(?![\d./:-])/g)].map(m=>m[0]);
    if(!tokens.length){const m=source.match(/(?:total|amount|ยอดสุทธิ|รวมสุทธิ|ยอดชำระ|ยอดรวม|จำนวนเงิน|ยอดเงิน|รวมเป็นเงิน|รวมทั้งสิ้น|รวมเงิน)\s*[:=]?\s*(\d{1,9})\s*(?:บาท|THB|฿)?\s*$/i);if(m)tokens.push(m[1]);}
    for(const token of tokens){try{const satang=parseMoney(token.replace(/,/g,''));if(satang>0&&!candidates.some(c=>c.satang===satang))candidates.push({satang,value:(satang/100).toFixed(2),source:source.slice(0,250),priority:strong?2:1});}catch{}}
  }
  candidates.sort((a,b)=>b.priority-a.priority);
  const slip=/โอนเงิน|โอนสำเร็จ|โอนเงินสำเร็จ|ผู้รับเงิน|ผู้โอน|transfer|พร้อมเพย์|promptpay/i.test(normalized);
  const merchant=lines.find(line=>!slip&&line.length>=2&&line.length<=100&&/[ก-๙a-z]/i.test(line)&&!/^\s*(ใบเสร็จ|receipt|tax invoice|วันที่|date|เวลา|tel|โทร|เลข|tax id|สาขา|vat|total|amount|เงินสด|เงินทอน|รวม|สุทธิ|จำนวนเงิน|ยอด|บาท|รายการ|หมายเลข|ค่าธรรมเนียม|สินค้า|subtotal|cash|change|grand)/i.test(line)&&!/^\d/.test(line));
  const warnings=[];
  if(!candidates.length)warnings.push('ยังหายอดรวมไม่พบ กรุณากรอกจากรูป');
  if(candidates.length>1)warnings.push('พบหลายยอด กรุณาเลือกยอดที่ถูกต้อง');
  if(dates.length!==1)warnings.push(dates.length?'พบหลายวันที่ กรุณาตรวจอีกครั้ง':'ยังอ่านวันที่ไม่ได้ กรุณาเลือกเอง');
  if(slip)warnings.push('สลิปอาจเป็นเงินเข้า เงินออก หรือย้ายเงินของตัวเอง กรุณาเลือกให้ถูก');
  return { documentType:slip?'slip':'receipt', amount:candidates.length===1?candidates[0].value:'', candidates, date:dates.length===1?dates[0].value:'', dates, name:merchant||'', warnings, text:normalized };
}
