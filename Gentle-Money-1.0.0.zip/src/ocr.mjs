// Create a derivative only. The attached original remains unchanged.
async function prepare(blob) {
  const url=URL.createObjectURL(blob),image=new Image();
  try {
    image.src=url;await image.decode();
    const scale=Math.min(2000/image.naturalWidth,4000/image.naturalHeight,Math.max(1,1400/image.naturalWidth));
    const canvas=document.createElement('canvas');canvas.width=Math.round(image.naturalWidth*scale);canvas.height=Math.round(image.naturalHeight*scale);
    const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,0,0,canvas.width,canvas.height);
    return await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error('ภาพไม่พร้อม')),'image/png'));
  } finally {URL.revokeObjectURL(url);}
}
export async function recognizePhoto(blob,{signal,onProgress=()=>{}}={}) {
  const image=await prepare(blob);
  if(signal?.aborted)throw new DOMException('ยกเลิกการอ่าน','AbortError');
  return new Promise((resolve,reject)=>{
    const worker=new Worker(new URL('./ocr-worker.js',import.meta.url));
    const finish=(error,text)=>{clearTimeout(timer);signal?.removeEventListener('abort',cancel);worker.terminate();if(error)reject(error);else resolve(text);};
    const cancel=()=>finish(new DOMException('ยกเลิกการอ่าน','AbortError'));
    const timer=setTimeout(()=>finish(Error('อ่านรูปนานเกินไป ลองใช้รูปที่ครอปชัดขึ้น หรือกรอกเองได้')),90000);
    worker.onmessage=({data})=>{if(data.type==='progress')onProgress(data);else if(data.type==='result')finish(null,data.text);else finish(Error('อ่านรูปไม่สำเร็จ ยังจดเองและแนบรูปได้ตามปกติ'));};
    worker.onerror=()=>finish(Error('เครื่องมืออ่านรูปเปิดไม่ได้ กรุณาโหลดหน้าใหม่ หรือกรอกเองก่อน'));
    signal?.addEventListener('abort',cancel,{once:true});worker.postMessage({blob:image});
  });
}
