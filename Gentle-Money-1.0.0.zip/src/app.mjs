import { installPlansUI } from './plans-ui.mjs';
import { installOverviewUI } from './overview-ui.mjs';
import { installPWA } from './pwa.mjs';
import { openDatabase, commit, readState, attachmentsFor, matchesFor } from './database.mjs';
import { recognizePhoto } from './ocr.mjs';
import { parseReceipt } from './receipt-parser.mjs';
import { preparePhoto } from './photos.mjs';
import { parseMoney, summarize, frequentEntries, bangkokDate, validDate, billOccurrences, savingForBill, paidEntry } from './ledger.mjs';
const $ = id => document.getElementById(id);
const money = n => (n / 100).toLocaleString('th-TH', { minimumFractionDigits: n % 100 ? 2 : 0, maximumFractionDigits: 2 });
const dateLabel = date => new Intl.DateTimeFormat('th-TH', { day:'numeric', month:'short', year:'numeric', timeZone:'Asia/Bangkok' }).format(new Date(date + 'T00:00:00Z'));
const today = () => bangkokDate();
let db, state, page='home', kind='expense', editing=null, draftId, accountDraftId, busy=false, photos=[], removedPhotos=[];
let reading=false,ocrController=null;
const pages=['loading','home','account-page','entry-page','history','bills-page','bill-form-page','plans-page','overview-page'];
const channel = typeof BroadcastChannel === 'function' ? new BroadcastChannel('gentle-money-changes') : null;
const plansUI=installPlansUI({getState:()=>state,refresh,write,task,show,openEntry,money,today,dateLabel,renderApp:render,message});
const overviewUI=installOverviewUI({getState:()=>state,getDB:()=>db,refresh,task,show,money,today,dateLabel,message,changed:()=>channel?.postMessage('changed')});
function message(s='') { $('message').textContent=s; }
function error(e) { $('error').textContent=e?.message || String(e || ''); }
function el(tag, text, cls) { const node=document.createElement(tag);node.textContent=text;if(cls)node.className=cls;return node; }
function options(node, values, empty) { const old=node.value;node.replaceChildren();if(empty!==undefined)node.add(new Option(empty,''));for(const v of values)node.add(new Option(v.name,v.id));if([...node.options].some(o=>o.value===old))node.value=old; }
function show(next) { page=next;for(const id of pages)$(id).hidden=id!==next;document.querySelector('nav').hidden=!['home','history'].includes(next);document.querySelectorAll('[data-nav]').forEach(b=>{if(b.dataset.nav===next)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});error(''); }
async function refresh() { state=await readState(db);render(); }
async function task(fn) {
  if(busy||reading)return;busy=true;error('');document.querySelectorAll('button').forEach(b=>b.disabled=true);
  try { await fn(); } catch(e) { error(e); } finally { busy=false;document.querySelectorAll('button').forEach(b=>b.disabled=false); }
}
async function write(command, changes) { state=await commit(db,command,changes);channel?.postMessage('changed'); }
function sortedEntries() { return state.entries.filter(e=>!e.deleted).sort((a,b)=>b.date.localeCompare(a.date)||state.entries.indexOf(b)-state.entries.indexOf(a)); }
function rows(container, entries) {
  container.replaceChildren();if(!entries.length){container.append(el('p','ยังไม่มีรายการ','muted small'));return;}
  for(const e of entries){const row=el('button','','row');row.type='button';row.dataset.entryId=e.id;const body=el('span','','text');body.append(el('span',e.name,'title'));const account=state.accounts.find(a=>a.id===e.accountId)?.name || '';const category=state.categories.find(c=>c.id===e.categoryId)?.name;body.append(el('span',dateLabel(e.date)+' · '+account+(e.kind==='transfer'?' → '+state.accounts.find(a=>a.id===e.toAccountId)?.name:category?' · '+category:''),'meta'));row.append(body,el('span',(e.kind==='income'?'+':e.kind==='expense'?'−':'↔ ')+money(e.amount),'value'));row.onclick=()=>task(async()=>{await refresh();const current=state.entries.find(x=>x.id===e.id&&!x.deleted);if(!current)throw Error('รายการนี้ถูกลบแล้ว');await openEntry(current);});container.append(row);}
}
function renderHistory() {
  const term=$('search').value.trim().toLocaleLowerCase('th-TH'),month=$('month').value,account=$('filter-account').value,category=$('filter-category').value;
  const entries=sortedEntries().filter(e=>(!term||(e.name+' '+(e.note||'')).toLocaleLowerCase('th-TH').includes(term))&&(!month||e.date.startsWith(month))&&(!account||e.accountId===account||e.toAccountId===account)&&(!category||e.categoryId===category));
  $('history-count').textContent=entries.length+' รายการ · แตะรายการเพื่อแก้ไข';rows($('history-list'),entries);
}
function render() {
  const sums=summarize(state,{to:today()});$('today').textContent=dateLabel(today());const balance=$('balance'),previous=balance.dataset.amount;balance.textContent=money(sums.cash);balance.dataset.amount=String(sums.cash);if(previous!==undefined&&previous!==String(sums.cash)&&!matchMedia('(prefers-reduced-motion: reduce)').matches){balance.getAnimations().forEach(a=>a.cancel());balance.animate([{opacity:.55,transform:'translateY(4px)'},{opacity:1,transform:'translateY(0)'}],{duration:240,easing:'ease-out'});}$('negative').hidden=!state.accounts.some(a=>a.type==='asset'&&sums.balances[a.id]<0);
  $('accounts').replaceChildren();for(const a of state.accounts){const row=el('div','','pair');row.append(el('span',a.name+(a.type==='liability'?' · หนี้':'')),el('span',money(sums.balances[a.id])+' บาท','value'));$('accounts').append(row);}
  rows($('recent'),sortedEntries().slice(0,3));options($('filter-account'),state.accounts,'ทุกบัญชี');options($('filter-category'),state.categories,'ทุกหมวด');renderHistory();renderBills();plansUI.render();overviewUI.render();
}
function renderKind() {
  document.querySelectorAll('[data-kind]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.kind===kind)));
  $('destination').hidden=kind!=='transfer';$('category-wrap').hidden=kind==='transfer';$('repeat-section').hidden=kind==='transfer'||!!editing;
  $('entry-account-label').textContent=kind==='income'?'เงินเข้าบัญชี':kind==='transfer'?'จากบัญชี':'ใช้เงินจากบัญชี';
  options($('category'),state.categories.filter(c=>c.kind===kind),'ยังไม่ระบุ');
  $('frequent').replaceChildren();for(const item of frequentEntries(state,kind)){const b=el('button',item.name);b.type='button';b.onclick=()=>{$('entry-name').value=item.name;$('amount').value='';$('amount').focus();};$('frequent').append(b);}
  if(!$('frequent').children.length)$('frequent').append(el('span','จดแล้วครั้งหน้าจะเลือกซ้ำได้','small muted'));
}
function clearPhoto(){for(const photo of photos)if(photo.url)URL.revokeObjectURL(photo.url);photos=[];removedPhotos=[];$('file').value='';$('capture').value='';$('photo-gallery').replaceChildren();$('photo-status').textContent='แนบได้ 10 รูป · JPG, PNG, WebP · รูปละไม่เกิน 20 MB';if($('photo-viewer').open)$('photo-viewer').close();$('large-photo').removeAttribute('src');}
function renderPhotos(){
  const gallery=$('photo-gallery');gallery.replaceChildren();
  for(const photo of photos){if(!photo.url)photo.url=URL.createObjectURL(photo.blob);const tile=el('div','','photo-tile');const open=el('button','','photo-open');open.type='button';open.setAttribute('aria-label','เปิดดูรูป '+photo.name);const image=new Image();image.src=photo.url;image.alt=photo.name;open.append(image);open.onclick=()=>{$('large-photo').src=photo.url;$('large-photo').alt=photo.name;$('photo-caption').textContent=photo.name;$('photo-viewer').showModal();};const caption=el('p',photo.name,'small muted');const remove=el('button','เอารูปออก','small');remove.type='button';remove.onclick=()=>{if(busy)return;if(photo.saved)removedPhotos.push(photo.id);URL.revokeObjectURL(photo.url);photos=photos.filter(p=>p!==photo);renderPhotos();};const read=el('button','อ่านข้อมูลจากรูป','small');read.type='button';read.className='read-photo secondary small';read.onclick=()=>readPhoto(photo);tile.append(open,caption,read,remove);gallery.append(tile);}
  $('photo-status').textContent=photos.length?photos.length+' รูป · กดบันทึกเพื่อเก็บการเปลี่ยนแปลง':'แนบได้ 10 รูป · JPG, PNG, WebP · รูปละไม่เกิน 20 MB';
}
async function openEntry(entry=null) {
  editing=entry?structuredClone(entry):null;draftId=crypto.randomUUID();$('entry-form').reset();clearPhoto();kind=entry?.kind||'expense';$('entry-title').textContent=entry?'แก้ไขรายการ':'จดรายการ';$('save-entry').textContent=entry?'บันทึกการแก้ไข':'บันทึก';$('delete-entry').hidden=!entry;$('delete-confirm').hidden=true;
  options($('entry-account'),state.accounts);options($('to-account'),state.accounts);renderKind();
  $('entry-date').max=today();$('entry-date').value=entry?.date||today();$('entry-details').open=!!entry;
  if(entry){$('amount').value=(entry.amount/100).toFixed(2);$('entry-name').value=entry.name;$('entry-account').value=entry.accountId;$('to-account').value=entry.toAccountId||'';$('category').value=entry.categoryId||'';$('note').value=entry.note||'';}
  else if(state.accounts.length>1)$('to-account').value=state.accounts[1].id;
  if(entry)photos=(await attachmentsFor(db,entry.id)).map(p=>({...p,saved:true}));renderPhotos();$('photo-details').open=photos.length>0;const linkedDebt=(state.debtPayments||[]).some(p=>p.principalEntryId===entry?.id||p.feeEntryId===entry?.id);const linkedGoal=(state.goalMoves||[]).some(m=>m.entryId&&m.entryId===entry?.id);$('linked-entry-hint').hidden=!linkedDebt&&!linkedGoal;$('linked-entry-hint').textContent=linkedDebt?'การชำระหนี้แยกยอดลดหนี้กับดอกเบี้ย การลบจะคืนยอดทั้งชุด':linkedGoal?'รายการนี้ใช้เงินจากเป้าหมาย การลบจะคืนเงินที่กันไว้ให้เป้าหมาย':'';document.querySelector('#delete-confirm p').textContent=linkedDebt?'ลบการชำระหนี้ทั้งชุด รวมดอกเบี้ยและรูปแนบหรือไม่? ยอดเงินและหนี้จะคำนวณใหม่':linkedGoal?'ลบรายจ่ายนี้และรูปแนบหรือไม่? เงินจะกลับเป็นเงินที่กันไว้ในเป้าหมาย':'ลบรายการนี้และรูปแนบทั้งหมดหรือไม่? ยอดเงินจะคำนวณใหม่';show('entry-page');message('');
}
function openAccount(){$('account-form').reset();accountDraftId=crypto.randomUUID();$('opened-on').max=today();$('opened-on').value=today();$('account-title').textContent=state.accounts.length?'เพิ่มบัญชี':'เริ่มจากเงินที่มี';$('cancel-account').hidden=!state.accounts.length;$('opening-label').textContent='เงินที่มีตอนเริ่มจด · บาท';show('account-page');}
const dirty=()=>page==='entry-page'&&($('entry-name').value||$('amount').value||photos.some(p=>!p.saved)||removedPhotos.length);
function leave(){if(dirty()&&!confirm('ออกจากหน้านี้โดยไม่บันทึกการเปลี่ยนแปลงหรือไม่?'))return;clearPhoto();show('home');render();}
$('cancel-entry').onclick=leave;$('cancel-account').onclick=()=>show('home');
$('add-entry').onclick=()=>task(async()=>{await refresh();await openEntry();});$('add-account').onclick=openAccount;
document.querySelectorAll('[data-nav]').forEach(b=>b.onclick=()=>task(async()=>{await refresh();show(b.dataset.nav);}));
document.querySelectorAll('[data-kind]').forEach(b=>b.onclick=()=>{kind=b.dataset.kind;renderKind();});
$('account-type').onchange=()=>{$('opening-label').textContent=$('account-type').value==='liability'?'ยอดหนี้ที่ค้างตอนเริ่มจด · บาท':'เงินที่มีตอนเริ่มจด · บาท';};
$('account-form').onsubmit=e=>{e.preventDefault();task(async()=>{const opening=parseMoney($('opening').value);if($('opened-on').value>today())throw Error('วันเริ่มต้นต้องไม่เกินวันนี้');await write({type:'account.create',id:accountDraftId,data:{name:$('account-name').value,type:$('account-type').value,opening:$('account-type').value==='liability'?-opening:opening,openedOn:$('opened-on').value}});show('home');render();message('เพิ่มบัญชีแล้ว');});};
$('entry-form').onsubmit=e=>{e.preventDefault();task(async()=>{if($('entry-date').value>today())throw Error('รายการเงินจริงต้องไม่เป็นวันในอนาคต');const data={kind,name:$('entry-name').value,amount:parseMoney($('amount').value),date:$('entry-date').value,accountId:$('entry-account').value,toAccountId:kind==='transfer'?$('to-account').value:null,categoryId:kind==='transfer'?null:$('category').value||null,note:$('note').value};if(!editing&&state.entries.some(e=>!e.deleted&&e.date===data.date&&e.amount===data.amount&&e.kind===data.kind)&&!confirm('พบรายการประเภทเดียวกัน ยอดและวันที่ตรงกัน อาจจดซ้ำ ต้องการบันทึกเพิ่มหรือไม่?'))return;await write(editing?{type:'entry.update',id:editing.id,expectedRevision:editing.revision,data}:{type:'entry.create',id:draftId,requestId:draftId,data}, {add:photos.filter(p=>!p.saved).map(({url,saved,...p})=>p),remove:removedPhotos});clearPhoto();editing=null;show('home');render();message('บันทึกรายการและรูปแนบแล้ว');});};
$('delete-entry').onclick=()=>{$('delete-confirm').hidden=false;};$('keep-entry').onclick=()=>{$('delete-confirm').hidden=true;};
$('confirm-delete').onclick=()=>task(async()=>{await write({type:'entry.delete',id:editing.id,expectedRevision:editing.revision});editing=null;clearPhoto();show('home');render();message('ลบรายการแล้ว ยอดเงินปรับให้แล้ว');});
for(const id of ['search','month','filter-account','filter-category'])$(id).addEventListener('input',renderHistory);
$('reset-filters').onclick=()=>{for(const id of ['search','month','filter-account','filter-category'])$(id).value='';renderHistory();};
async function selectPhoto(e){const files=[...(e.target.files||[])];e.target.value='';if(!files.length)return;task(async()=>{const problems=[];for(const file of files){try{if(photos.length>=10)throw Error('แนบได้ไม่เกิน 10 รูปต่อรายการ');const photo=await preparePhoto(file);if(photos.some(p=>p.hash===photo.hash)){problems.push('รูปนี้อยู่ในรายการแล้ว ไม่เพิ่มซ้ำ');continue;}const matches=(await matchesFor(db,photo.hash)).filter(p=>p.entryId!==(editing?.id||draftId));if(matches.length&&!confirm('พบรูปเดียวกันในรายการอื่น อาจจดซ้ำ ต้องการแนบกับรายการนี้ด้วยหรือไม่?'))continue;photos.push(photo);}catch(e){problems.push(e.message);}}renderPhotos();if(problems.length)$('photo-status').textContent=problems.join(' · ');});}
$('upload').onclick=()=>$('file').click();$('camera').onclick=()=>$('capture').click();$('file').onchange=selectPhoto;$('capture').onchange=selectPhoto;
$('close-photo').onclick=()=>$('photo-viewer').close();
async function backgroundRefresh(){if(!db||busy)return;try{await refresh();if(page==='entry-page')message('ข้อมูลอาจเปลี่ยนจากหน้าอื่น หากบันทึกไม่ได้ให้กลับแล้วเปิดรายการใหม่');}catch(e){error(e);}}
if(channel)channel.onmessage=backgroundRefresh;window.addEventListener('focus',backgroundRefresh);
async function init(){db=await openDatabase();state=await readState(db);const names={expense:['อาหาร','เดินทาง','ของใช้','บิล','ความสุข','อื่น ๆ'],income:['เงินเดือน','รายได้เสริม','อื่น ๆ']};for(const [type,items] of Object.entries(names)){for(const [i,name] of items.entries()){const id=`default-${type}-${i}`;if(state.categories.some(c=>c.id===id))continue;try{await write({type:'category.create',id,data:{name,kind:type}});}catch(e){state=await readState(db);if(!state.categories.some(c=>c.id===id))throw e;}}}render();if(state.accounts.length)show('home');else openAccount();}
init().catch(e=>{$('loading').textContent='เปิดฐานข้อมูลไม่ได้ ลองเปิดในเบราว์เซอร์ปกติที่อนุญาตให้เก็บข้อมูล แล้วโหลดหน้านี้ใหม่';error(e);});
installPWA();

function closeOCR(){ocrController?.abort();$('ocr-dialog').close();$('ocr-image').removeAttribute('src');}
$('ocr-close').onclick=closeOCR;$('ocr-dialog').addEventListener('cancel',()=>{ocrController?.abort();});
async function readPhoto(photo){
  if(busy||reading)return;reading=true;ocrController=new AbortController();$('ocr-error').textContent='';$('ocr-result').hidden=true;$('ocr-progress').textContent='กำลังเตรียมอ่านในเครื่อง… กดปิดเพื่อยกเลิกได้';$('ocr-image').src=photo.url;$('ocr-dialog').showModal();
  try{
    const text=await recognizePhoto(photo.blob,{signal:ocrController.signal,onProgress:info=>{$('ocr-progress').textContent=info.status==='recognizing text'?'กำลังอ่านข้อความ '+Math.round((info.progress||0)*100)+'%':'กำลังเตรียมเครื่องมืออ่านภาษาไทยและอังกฤษ…';}});
    const result=parseReceipt(text);$('ocr-progress').textContent=text.trim()?'อ่านเสร็จแล้ว กรุณาเทียบข้อมูลกับรูป':'ไม่พบข้อความที่ชัดเจน คุณยังกรอกเองได้';$('ocr-result').hidden=false;$('ocr-amount').value=result.amount;$('ocr-date').value=result.date;$('ocr-date').max=today();$('ocr-name').value=result.name;$('ocr-kind').value='';$('ocr-text').textContent=result.text.slice(0,12000);$('ocr-warnings').textContent=result.warnings.join(' · ');$('ocr-candidates').replaceChildren();$('ocr-amount-source').textContent=result.amount?result.candidates[0].source:'';
    for(const candidate of result.candidates){if(result.candidates.length<2)break;const button=el('button',candidate.value+' บาท');button.type='button';button.onclick=()=>{$('ocr-amount').value=candidate.value;$('ocr-amount-source').textContent=candidate.source;};$('ocr-candidates').append(button);}
  }catch(e){if(e.name!=='AbortError')$('ocr-progress').textContent=e.message;}
  finally{reading=false;ocrController=null;}
}
$('ocr-apply').onclick=()=>{
  try{
    const amount=parseMoney($('ocr-amount').value);if(amount<=0)throw Error('กรุณาใส่ยอดเงินที่มากกว่า 0');const date=validDate($('ocr-date').value);if(date>today())throw Error('กรุณาตรวจวันที่ ไม่ควรเกินวันนี้');const name=$('ocr-name').value.trim();if(!name)throw Error('กรุณาใส่ชื่อรายการ');const selectedKind=$('ocr-kind').value;if(!['expense','income','transfer'].includes(selectedKind))throw Error('กรุณาเลือกเงินเข้า เงินออก หรือย้ายเงิน');
    if(($('amount').value||$('entry-name').value)&&!confirm('นำข้อมูลที่ตรวจแล้วไปใส่แทนยอด ชื่อ วันที่ และประเภทในฟอร์มหรือไม่?'))return;
    kind=selectedKind;renderKind();$('amount').value=(amount/100).toFixed(2);$('entry-name').value=name;$('entry-date').value=date;$('entry-details').open=true;closeOCR();message('ใส่ข้อมูลจากรูปแล้ว กรุณาตรวจบัญชี หมวด และยอดก่อนกดบันทึก');
  }catch(e){$('ocr-error').textContent=e.message;}
};

let billEditing=null,billDraftId=null,payingBill=null,payEntryId=null,payExistingEntries=[];
function renderBills(){
 const occurrences=billOccurrences(state,today()),soon=occurrences.filter(o=>o.dueDate<=addDays(today(),7));
 const overdue=occurrences.filter(o=>o.status==='overdue').length;
 $('bill-summary').textContent=overdue?`เกินกำหนด ${overdue} รอบ`:soon.length?`ภายใน 7 วัน ${soon.length} รอบ`:occurrences.length?`${occurrences.length} รอบที่รอจ่าย`:'เพิ่มไว้เตือนตัวเอง';
 $('bills-list').replaceChildren();if(!occurrences.length)$('bills-list').append(el('p','ยังไม่มีบิลที่รอจ่าย','small muted'));
 for(const o of occurrences){const card=el('article','','bill-card');card.dataset.billId=o.billId;card.dataset.dueDate=o.dueDate;const heading=el('div','','bill-heading');const edit=el('button',o.name,'bill-name');edit.type='button';edit.setAttribute('aria-label','แก้ไขบิล '+o.name);edit.onclick=()=>task(async()=>{await refresh();const bill=state.bills.find(b=>b.id===o.billId&&!b.archived);if(!bill)throw Error('ไม่พบบิล กรุณาโหลดใหม่');openBill(bill);});heading.append(edit,el('span',money(o.amount)+' บาท','value'));const status=o.status==='overdue'?'เลยกำหนดแล้ว':o.status==='today'?'ครบกำหนดวันนี้':'ครบกำหนด '+dateLabel(o.dueDate);card.append(heading,el('p',status+(o.status==='overdue'?' · '+dateLabel(o.dueDate):''),o.status==='upcoming'?'small muted':'small warning'));
 const plan=savingForBill(o,today());let advice=plan.shortfall===0?'เตรียมเงินครบตามยอดที่ระบุแล้ว':plan.rounds===0?`ยังต้องเตรียม ${money(plan.shortfall)} บาท`:`ยังขาด ${money(plan.shortfall)} บาท · แบ่งอีก ${plan.rounds} รอบเดือน รอบละประมาณ ${money(plan.perMonth)} บาท`;
 card.append(el('p',advice,'small muted bill-plan'));const pay=el('button','จ่ายแล้ว','bill-pay');pay.type='button';pay.onclick=()=>task(async()=>{await refresh();const current=billOccurrences(state,today()).find(x=>x.billId===o.billId&&x.dueDate===o.dueDate);if(!current)throw Error('บิลรอบนี้เปลี่ยนแล้ว กรุณาตรวจรายการใหม่');openBillPayment(current);});card.append(pay);$('bills-list').append(card);}
 $('paid-bills').replaceChildren();let paid=0;for(const p of [...(state.billPayments||[])].reverse()){const entry=paidEntry(state,p.billId,p.dueDate);if(!entry)continue;paid++;const b=el('button',`${entry.name} · ${money(entry.amount)} บาท · ${dateLabel(entry.date)}`,'row');b.type='button';b.onclick=()=>task(async()=>{await refresh();const e=state.entries.find(x=>x.id===entry.id&&!x.deleted);if(!e)throw Error('รายการนี้ถูกลบแล้ว');await openEntry(e);});$('paid-bills').append(b);}if(!paid)$('paid-bills').append(el('p','ยังไม่มีบิลที่จ่ายแล้ว','small muted'));
}
function addDays(date,days){const d=new Date(date+'T00:00:00Z');d.setUTCDate(d.getUTCDate()+days);return d.toISOString().slice(0,10);}
function openBill(bill=null){
 if(bill===undefined)throw Error('ไม่พบบิล');billEditing=bill?structuredClone(bill):null;billDraftId=crypto.randomUUID();$('bill-form').reset();$('bill-title').textContent=bill?'แก้ไขบิล':'เพิ่มบิล';$('archive-bill').hidden=!bill;options($('bill-category'),state.categories.filter(c=>c.kind==='expense'),'ยังไม่ระบุ');$('bill-category').value=state.categories.find(c=>c.kind==='expense'&&c.name==='บิล')?.id||'';
 $('bill-name').value=bill?.name||'';$('bill-amount').value=bill?(bill.amount/100).toFixed(2):'';$('bill-due').value=bill?.dueDate||today();$('bill-repeat').value=bill?.repeat||'once';$('bill-prepared').value=bill?(bill.prepared/100).toFixed(2):'0';if(bill)$('bill-category').value=bill.categoryId||'';
 const hasHistory=!!bill&&(state.billPayments||[]).some(p=>p.billId===bill.id);$('bill-due').disabled=hasHistory;$('bill-repeat').disabled=hasHistory;$('bill-schedule-note').hidden=!hasHistory;show('bill-form-page');message('');
}
$('open-bills').onclick=()=>task(async()=>{await refresh();show('bills-page');});$('bills-back').onclick=()=>show('home');$('add-bill').onclick=()=>openBill();$('cancel-bill').onclick=()=>show('bills-page');
$('bill-form').onsubmit=e=>{e.preventDefault();task(async()=>{const data={name:$('bill-name').value,amount:parseMoney($('bill-amount').value),dueDate:$('bill-due').value,repeat:$('bill-repeat').value,prepared:parseMoney($('bill-prepared').value),categoryId:$('bill-category').value||null};await write(billEditing?{type:'bill.update',id:billEditing.id,expectedRevision:billEditing.revision,data}:{type:'bill.create',id:billDraftId,data});show('bills-page');render();message('บันทึกบิลแล้ว เงินในบัญชียังเท่าเดิม');});};
$('archive-bill').onclick=()=>task(async()=>{if(!confirm('หยุดเตือนบิลนี้และรอบถัดไปหรือไม่? รายจ่ายที่จ่ายแล้วจะยังอยู่'))return;await write({type:'bill.archive',id:billEditing.id,expectedRevision:billEditing.revision});show('bills-page');render();message('หยุดเตือนบิลนี้แล้ว');});
function payMode(){const existing=$('bill-pay-mode').value==='existing';$('bill-pay-new').hidden=existing;$('bill-pay-existing').hidden=!existing;for(const id of ['bill-pay-amount','bill-pay-date','bill-pay-account'])$(id).disabled=existing;$('bill-pay-entry').disabled=!existing;$('bill-pay-entry').required=existing;}
function openBillPayment(o){
 payingBill=o;payEntryId=crypto.randomUUID();$('bill-pay-form').reset();$('bill-pay-error').textContent='';$('bill-pay-title').textContent=o.name;$('bill-pay-detail').textContent='ครบกำหนด '+dateLabel(o.dueDate)+' · ยอดประมาณ '+money(o.amount)+' บาท';$('bill-pay-amount').value=(o.amount/100).toFixed(2);$('bill-pay-date').max=today();$('bill-pay-date').value=today();options($('bill-pay-account'),state.accounts);
 const used=new Set((state.billPayments||[]).map(p=>p.entryId));const entries=sortedEntries().filter(e=>e.kind==='expense'&&!used.has(e.id));payExistingEntries=structuredClone(entries);options($('bill-pay-entry'),entries.map(e=>({id:e.id,name:`${e.name} · ${money(e.amount)} บาท · ${dateLabel(e.date)}`})),'เลือกรายจ่ายเดิม');payMode();$('bill-pay-dialog').showModal();
}
$('bill-pay-mode').onchange=payMode;$('close-bill-pay').onclick=()=>$('bill-pay-dialog').close();
$('bill-pay-form').onsubmit=e=>{e.preventDefault();task(async()=>{try{let data={dueDate:payingBill.dueDate};if($('bill-pay-mode').value==='existing'){const entry=payExistingEntries.find(e=>e.id===$('bill-pay-entry').value&&!e.deleted);if(!entry)throw Error('กรุณาเลือกรายจ่ายที่จดไว้แล้ว');data={...data,existingEntryId:entry.id,expectedEntryRevision:entry.revision};}else{data={...data,entryId:payEntryId,requestId:payEntryId,amount:parseMoney($('bill-pay-amount').value),date:$('bill-pay-date').value,accountId:$('bill-pay-account').value};if(data.date>today())throw Error('วันที่จ่ายต้องไม่เกินวันนี้');if(state.entries.some(e=>!e.deleted&&e.kind==='expense'&&e.amount===data.amount&&e.date===data.date)&&!confirm('มีรายจ่ายยอดและวันที่ตรงกัน ถ้าจดแล้วให้เลือกรายการเดิม ต้องการสร้างรายจ่ายเพิ่มหรือไม่?'))return;}
 await write({type:'bill.pay',id:payingBill.billId,expectedRevision:payingBill.revision,data});$('bill-pay-dialog').close();show('bills-page');render();message('บันทึกว่าจ่ายแล้ว ไม่เพิ่มรายจ่ายซ้ำกับรายการเดิม');}catch(e){$('bill-pay-error').textContent=e.message;throw e;}});};
