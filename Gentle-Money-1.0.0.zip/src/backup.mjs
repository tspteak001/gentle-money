import { validateState, validDate } from './ledger.mjs';
import { preparePhoto } from './photos.mjs';
export const BACKUP_LIMIT = 300 * 1024 * 1024;
const check = ok => { if(!ok)throw Error('ไฟล์สำรองไม่ครบหรือเสียหาย ข้อมูลเดิมยังอยู่'); };
const digest = async bytes => [...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(n=>n.toString(16).padStart(2,'0')).join('');
function base64(bytes) { let s='';for(let i=0;i<bytes.length;i+=32768)s+=String.fromCharCode(...bytes.subarray(i,i+32768));return btoa(s); }
function preferences(p={}) {
  check(p && typeof p==='object' && !Array.isArray(p));
  check(Object.keys(p).every(k=>['until','living'].includes(k)));
  if(p.until!==undefined)validDate(p.until);
  if(p.living!==undefined)check(Number.isSafeInteger(p.living)&&p.living>=0&&p.living<=99999999999);
  return p;
}
export async function encodeBackup(snapshot, createdAt=new Date().toISOString()) {
  validateState(snapshot.state);preferences(snapshot.preferences);
  const attachments=[];let size=0;
  for(const p of snapshot.attachments) {
    size+=Math.ceil(p.blob.size/3)*4;check(size<BACKUP_LIMIT);
    attachments.push({id:p.id,entryId:p.entryId,hash:p.hash,name:p.name,width:p.width,height:p.height,type:p.blob.type,data:base64(new Uint8Array(await p.blob.arrayBuffer()))});
  }
  const payload=JSON.stringify({createdAt,state:snapshot.state,preferences:snapshot.preferences||{},attachments});
  const bytes=new TextEncoder().encode(payload);if(bytes.length>BACKUP_LIMIT-1024)throw Error('ไฟล์ใหญ่เกิน 300 MB กรุณาลดจำนวนหรือขนาดรูปก่อนสำรอง');
  const result=JSON.stringify({format:'gentle-money-full-backup',version:1,checksum:await digest(bytes),payload});
  if(new TextEncoder().encode(result).length>BACKUP_LIMIT)throw Error('ไฟล์ใหญ่เกิน 300 MB กรุณาลดจำนวนหรือขนาดรูปก่อนสำรอง');
  return result;
}
export async function decodeBackup(text) {
  check(typeof text==='string'&&new TextEncoder().encode(text).length<=BACKUP_LIMIT);
  let envelope;try{envelope=JSON.parse(text);}catch{throw Error('เปิดไฟล์นี้ไม่ได้ กรุณาเลือกไฟล์สำรอง .json ของ Gentle Money');}
  check(envelope?.format==='gentle-money-full-backup'&&envelope.version===1&&typeof envelope.payload==='string');
  check(envelope.checksum===await digest(new TextEncoder().encode(envelope.payload)));
  const data=JSON.parse(envelope.payload);check(typeof data.createdAt==='string'&&Number.isFinite(Date.parse(data.createdAt)));
  validateState(data.state);preferences(data.preferences);
  check(Array.isArray(data.attachments)&&data.attachments.length<=100000);
  const ids=new Set(),counts=new Map(),hashes=new Set(),attachments=[];
  for(const p of data.attachments) {
    check(typeof p.id==='string'&&p.id.length>0&&p.id.length<=100&&!ids.has(p.id));ids.add(p.id);
    check(data.state.entries.some(e=>e.id===p.entryId&&!e.deleted));
    const count=(counts.get(p.entryId)||0)+1;check(count<=10);counts.set(p.entryId,count);
    check(typeof p.name==='string'&&p.name.length>0&&p.name.length<=255&&/^[a-f0-9]{64}$/.test(p.hash));
    check(!hashes.has(p.entryId+':'+p.hash));hashes.add(p.entryId+':'+p.hash);
    check(['image/jpeg','image/png','image/webp'].includes(p.type));
    check(typeof p.data==='string'&&p.data.length%4===0&&p.data.length<=Math.ceil(20*1024*1024/3)*4&&/^[A-Za-z0-9+/]*={0,2}$/.test(p.data));
    const raw=atob(p.data),bytes=Uint8Array.from(raw,c=>c.charCodeAt(0));
    check(bytes.length<=20*1024*1024&&await digest(bytes)===p.hash);
    const photo=await preparePhoto(new Blob([bytes],{type:p.type}));
    check(photo.blob.type===p.type&&photo.width===p.width&&photo.height===p.height);
    attachments.push({id:p.id,entryId:p.entryId,hash:p.hash,name:p.name,width:p.width,height:p.height,blob:photo.blob});
  }
  return {state:data.state,preferences:data.preferences||{},attachments,createdAt:data.createdAt};
}
