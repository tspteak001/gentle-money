// Examples only. These functions never create transactions or move money.
const MAX=99999999999;
const amount=n=>{if(!Number.isSafeInteger(n)||n<0||n>MAX)throw Error('จำนวนเงินต้องไม่ติดลบและไม่เกินขอบเขตที่รองรับ');return n;};
const positive=n=>{amount(n);if(!n)throw Error('ยอดตั้งต้นต้องมากกว่า 0');return n;};
const count=n=>{if(!Number.isInteger(n)||n<1||n>1200)throw Error('ใส่จำนวนเต็มตั้งแต่ 1 ถึง 1,200');return n;};
export const methods=[
 {id:'income',name:'กันเก็บเมื่อเงินเข้า',description:'เลือกกันจำนวนเล็ก ๆ เมื่อได้รับเงินจริง ดูบิล หนี้ และค่ากินอยู่ก่อน ไม่จำเป็นต้องเริ่มด้วยเปอร์เซ็นต์สูง',fields:[['base','เงินเข้าที่ใช้เป็นตัวอย่าง · บาท','20000'],['percent','ลองกันกี่เปอร์เซ็นต์','5','percent']]},
 {id:'ratio',name:'แบ่งเงินเป็นสัดส่วน',description:'50/30/20 เป็นตัวอย่างที่ปรับได้ ไม่ใช่เกณฑ์ตัดสินว่าคุณใช้เงินถูกหรือผิด ส่วนเก็บ/จ่ายหนี้เพิ่มเป็นก้อนเดียว ต้องเลือกแบ่งอีกที',fields:[['base','เงินเข้าที่ใช้เป็นตัวอย่าง · บาท','20000'],['needs','จำเป็น · %','50','percent'],['wants','ความสุข · %','30','percent'],['save','เก็บ / จ่ายหนี้เพิ่ม · %','20','percent']]},
 {id:'envelope',name:'แยกงบเป็นซอง',description:'กำหนดวงเงินให้แต่ละเรื่อง เช่น อาหารหรือเดินทาง แล้วเทียบกับยอดที่ใช้ ไม่ต้องเปิดบัญชีธนาคารหลายบัญชี เครื่องมือนี้เป็นตัวอย่างคำนวณ ยังไม่ได้สร้างซองในบัญชีจริง',fields:[['base','งบซองตัวอย่าง · บาท','3000'],['used','ใช้ไปแล้วในตัวอย่าง · บาท','700']]},
 {id:'goal',name:'เก็บตามเป้าหมาย',description:'หักเงินที่มีแล้วจากเป้าหมาย แล้วแบ่งตามรอบที่ยังเก็บได้ หากต้องเก็บต่อรอบมากเกินกำลัง ลองลดเป้าหมายหรือเลื่อนวัน',fields:[['base','เป้าหมายตัวอย่าง · บาท','6000'],['saved','มีแล้วในตัวอย่าง · บาท','1000'],['rounds','ยังเก็บได้อีกกี่รอบ','5','count']]},
 {id:'annual',name:'แบ่งเตรียมบิลก้อนใหญ่',description:'บิลที่รู้อยู่แล้ว เช่น ประกันหรือค่าเทอม ค่อย ๆ เตรียมก่อนถึงวันจ่าย แยกจากเงินฉุกเฉิน ในบัญชีจริงใช้ช่องเงินเตรียมบิลเพื่อไม่กันเงินซ้ำ',fields:[['base','ยอดบิลตัวอย่าง · บาท','12000'],['saved','เตรียมแล้วในตัวอย่าง · บาท','2000'],['rounds','ยังเก็บได้อีกกี่รอบ','10','count']]},
 {id:'emergency',name:'เริ่มเงินเผื่อฉุกเฉิน',description:'เผื่อเหตุจำเป็นที่ไม่ได้คาด เช่น รายได้สะดุดหรือซ่อมของเร่งด่วน เริ่มด้วยยอดเล็กตามกำลังได้ จำนวนเดือนในตัวอย่างเลือกเอง ไม่ใช่เป้าหมายที่ทุกคนต้องทำ',fields:[['base','ค่าใช้จ่ายจำเป็นต่อเดือนในตัวอย่าง · บาท','10000'],['months','ลองเผื่อกี่เดือน','3','count']]},
 {id:'small',name:'เก็บทีละน้อย / ปัดเศษ',description:'ซื้อของ 47 บาทแล้วลองกันเพิ่ม 3 บาท รายจ่ายยังเป็น 47 บาท เงินเก็บเป็นการกันอีกส่วน ข้ามหรือหยุดได้เมื่อเงินยังต้องใช้กับเรื่องจำเป็น',fields:[['base','ราคาซื้อในตัวอย่าง · บาท','47'],['step','ลองปัดให้เต็มทีละ · บาท','10']]},
 {id:'irregular',name:'วางแผนเมื่อรายได้ไม่แน่นอน',description:'เริ่มจากเงินที่ได้รับจริง หักภาระและค่าครองชีพที่ยังต้องใช้ก่อน ส่วนที่เหลือเป็นเพียงขอบเขตให้พิจารณา ไม่ได้แนะนำให้เก็บทั้งหมด',fields:[['base','เงินที่ได้รับในตัวอย่าง · บาท','3000'],['needed','ภาระที่ยังต้องใช้ในตัวอย่าง · บาท','2800']]},
];
export function calculateExample(method,data){
 const base=amount(data.base);
 if(method==='income') {if(!Number.isInteger(data.percent)||data.percent<0||data.percent>100)throw Error('เปอร์เซ็นต์ต้องเป็นจำนวนเต็ม 0–100');return {saving:Math.floor(base*data.percent/100)};}
 if(method==='ratio'){
  const ps=[data.needs,data.wants,data.save];if(ps.some(p=>!Number.isInteger(p)||p<0||p>100)||ps.reduce((s,p)=>s+p,0)!==100)throw Error('สัดส่วนต้องเป็นจำนวนเต็มและรวมกันได้ 100%');
  const needs=Math.floor(base*ps[0]/100),wants=Math.floor(base*ps[1]/100);return {needs,wants,saving:base-needs-wants};
 }
 if(method==='envelope')return {remaining:base-amount(data.used)};
 if(method==='goal'||method==='annual'){const missing=Math.max(0,base-amount(data.saved));const rounds=count(data.rounds);return {missing,rounds,perRound:Math.ceil(missing/rounds)};}
 if(method==='emergency')return {target:amount(base*count(data.months))};
 if(method==='small'){const step=positive(data.step);return {saving:(step-base%step)%step};}
 if(method==='irregular')return {remaining:base-amount(data.needed)};
 throw Error('ไม่พบวิธีจัดเงินนี้');
}
export function guidance(forecast,asOf){
 if(!forecast||forecast.until<asOf)return {code:'missing',text:'ยังไม่แนะนำยอดจากบัญชีจริง เลือกช่วงวางแผนในภาพรวมก่อน ตัวเลขด้านล่างเป็นเพียงตัวอย่าง'};
 if(forecast.available<0)return {code:'shortfall',amount:-forecast.available,text:'เงินตามแผนยังไม่พอ ลองทบทวนรายการที่ต้องจ่ายและปรับเป้าหมายเงินเก็บก่อน ยังไม่เสนอให้กันเงินเพิ่ม'};
 if(forecast.debtsWithoutSchedule.length)return {code:'debt',text:'มีหนี้ที่ยังไม่มีรอบชำระครบ กรุณาเติมข้อมูลก่อนตัดสินใจเก็บเพิ่ม ตัวอย่างไม่ได้รวมภาระที่ยังไม่ทราบ'};
 if(!forecast.living)return {code:'living',text:'ยังไม่ได้เผื่อค่ากินอยู่หรือค่าใช้จ่ายอื่นในแผน จึงยังไม่แนะนำยอดเก็บจากเงินในบัญชีจริง'};
 return {code:'review',amount:forecast.available,text:'มีส่วนว่างตามข้อมูลที่จด แต่ต้องตรวจว่าบิล หนี้ และค่ากินอยู่ครบก่อนเลือกแบ่งเก็บ ตัวอย่างไม่ได้กันหรือโอนเงินจริง'};
}
